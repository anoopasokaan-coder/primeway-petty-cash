PRIMEWAY & LOLLYBIRD - ANDROID VERSION 5.0

STANDALONE AT THE DEPOTS
No office PC, local server, Python or desktop connection is required to use
this app on the tablet. Camera, gallery, ledger, agents/depots, cash cycles,
exchange rates, warnings, approval reports and exports run on Android.
Camera / Choose photo / Voice / Readers have prominent buttons. Forms scroll
and reflow for tablet and phone screens; the keyboard resizes the window.

INSTALLATION
This ZIP contains source, not a compiled APK. It cannot be installed by tapping
the ZIP. Build an APK once on a computer using Android Studio, JDK 17 and SDK
Platform 35, or use Build_APK.bat after installing the listed build tools.
The build outputs PrimeWay_Lollybird_Petty_Cash.apk. Transfer that APK to the
tablet, tap it and allow Install unknown apps for the app opening the file.
After installation, no development tools are required on the tablet.
Minimum Android 6. A modern Android System WebView is required.
Update over the existing app with the same signing key. Uninstalling deletes
private cash data; share a backup first. Debug builds use the computer's debug
key; changing build computers can prevent an in-place update.

PHOTO READING
Use Camera or Choose photo. Keep the voucher straight, landscape and filling
the photograph. The app normalizes camera orientation and enhances ink for
field reading. Device ML Kit OCR is included and works offline, primarily for
printed text. Faint carbon copies and handwriting may be wrong.
For stronger handwriting reading over mobile internet: Readers > Azure.
Enter your own Document Intelligence endpoint and API key, enable reading,
then take / select the photo. Photos are sent directly to Azure, not to any
PC. No API key is included. Your account limits and charges apply.
Every field is an unconfirmed suggestion. Check the date (day-month-year),
PCV/PCB number, payee, amount, LD/USD and exchange rate before Save.
No OCR can promise perfect extraction from every photograph.

VOICE AND AUDIO NOTES
Voice > Speak field uses the installed Android speech recognition service.
Choose English India, US or UK. Review alternatives or correct the recognized
text, then Apply. Device speech may use the provider's online service.
Prefer offline is a request to the provider, not a guarantee; install language
packs if required. If speech is unavailable, enable a speech service or use
Gboard's microphone directly in a text field.
Record voice note saves an M4A recording separately (maximum 60 seconds).
Tap Stop. It stops automatically when leaving the app. Microphone permission
is required. Saved audio is attached to the voucher when saved, included in
the backup and can be shared from the ledger. A saved voice recording is NOT
automatically transcribed. Use Speak field for voice-to-text.

SHARING TO OFFICE
Ledger > Share Excel workbook exports a real .xlsx file with expense fields,
original currency, rate, USD equivalent, voucher number, photo/note filenames
and cycle. Numeric amounts are spreadsheet numbers. This is an expense data
export, not a desktop database-import operation.
Share CSV provides another Excel-compatible format.
Share backup ZIP includes the ledger, saved photos, audio notes and archived
reports. Photos/audio are not embedded inside the Excel file; send the backup
when source attachments are needed. Backups are exports; no restore/import
screen is included. The Android and Windows ledgers are not auto-synchronized.
Android's share chooser lets you select installed WhatsApp or email apps.
Report > Print / save PDF opens Android printing; choose Save as PDF and
share that PDF from Files. Report HTML can also be shared directly.

VALIDATION
Existing ledger and input test suites passed, including conversion, historical
rates, agent reassignment, duplicates, replenishment and report totals. JS syntax
and HTML element references were checked. This environment has no Android SDK
or Java compiler, so no APK was compiled, no XLSX exporter was executed, and
camera, microphone, report printing, live Azure OCR and tablet layout have NOT
been device-tested. Review these on the target tablet before routine use.
