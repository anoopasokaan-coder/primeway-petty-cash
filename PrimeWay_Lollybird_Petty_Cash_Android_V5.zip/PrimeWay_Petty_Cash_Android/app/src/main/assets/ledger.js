(function(global){
'use strict';
function decimal(v,places){
 const s=String(v).trim(); if(!/^\d+(\.\d+)?$/.test(s))throw Error('Enter a positive numeric value.');
 const [a,b='']=s.split('.'); if(b.length>places)throw Error('Too many decimal places.');
 const n=Number(a)*10**places+Number(b.padEnd(places,'0'));if(!Number.isSafeInteger(n)||n>1e12)throw Error('Amount exceeds supported range.');return n;
}
function money(v){return decimal(v,2);}
function validDate(s){s=String(s).trim();const iso=s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/),m=s.match(/^(\d{1,2})\s*[-/.,\s]\s*(\d{1,2})\s*[-/.,\s]\s*(\d{4})$/);if(iso)s=iso[1]+'-'+iso[2].padStart(2,'0')+'-'+iso[3].padStart(2,'0');else if(m)s=m[3]+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0');if(!/^\d{4}-\d{2}-\d{2}$/.test(s)||!Number.isFinite(new Date(s+'T00:00:00Z').getTime())||new Date(s+'T00:00:00Z').toISOString().slice(0,10)!==s)throw Error('Use a valid day-month-year date, for example 7-10-2026.');return s;}
function empty(){return {version:1,threshold:5000,funds:[],vouchers:[],rates:[]};}
function balance(s){return s.funds.reduce((a,r)=>a+r.amount,0)-s.vouchers.reduce((a,r)=>a+r.usd,0);}
function cycle(s){return s.funds.length;}
function nameKey(v){return String(v||'').toLowerCase().replace(/[^\p{L}\p{N}\s]/gu,' ').trim().replace(/\s+/g,' ');}
function initializeMaster(s,seed){if(s.masterVersion===1)return false;s.agents=Object.entries(seed).map(([name,depot])=>({name,depot,aliases:[]}));s.depots=[...new Set(Object.values(seed))].sort();s.masterVersion=1;return true;}
function resolveAgent(s,name){const k=nameKey(name);if(!k)return null;return (s.agents||[]).find(a=>nameKey(a.name)===k||(a.aliases||[]).some(x=>nameKey(x)===k))||null;}
function addDepot(s,name){name=String(name).trim();if(!name)throw Error('Enter a depot name.');if(!(s.depots||[]).some(d=>nameKey(d)===nameKey(name)))s.depots.push(name);s.depots.sort();}
function saveAgent(s,v){
 const name=String(v.name||'').trim(),depot=String(v.depot||'').trim(),old=(s.agents||[]).find(a=>a.name===v.old_name);
 if(!name||!depot)throw Error('Agent name and assigned depot are required.');if(!(s.depots||[]).includes(depot))throw Error('Add the depot to the master first.');
 if(v.old_name&&!old)throw Error('Selected agent no longer exists.');
 const aliases=[...(v.aliases||[]),...(old?.aliases||[]),...(old&&old.name!==name?[old.name]:[])].map(x=>String(x).trim()).filter(x=>x&&nameKey(x)!==nameKey(name));
 for(const x of [name,...aliases]){const match=resolveAgent(s,x);if(match&&match!==old)throw Error('Name or alias already belongs to '+match.name);}
 const saved={name,depot,aliases:[...new Set(aliases)]};if(old)s.agents[s.agents.indexOf(old)]=saved;else s.agents.push(saved);s.agents.sort((a,b)=>a.name.localeCompare(b.name));
}
function status(s){const b=balance(s);return b<=0?'CASH FINISHED — REPLENISH NOW':b<=s.threshold?'TIME TO REPLENISH':'CASH AVAILABLE';}
function fund(s,v){const when=validDate(v.date);const amount=money(v.amount);if(!amount||!v.reference.trim())throw Error('Enter cash received and a receipt reference.');s.funds.push({id:cycle(s)+1,date:when,amount,reference:v.reference.trim()});}
function setRate(s,date,rate){date=validDate(date);const units=decimal(rate,6);if(!units)throw Error('Rate must be greater than zero.');s.rates=s.rates.filter(r=>r.date!==date);s.rates.push({date,rate:String(rate)});s.rates.sort((a,b)=>a.date.localeCompare(b.date));}
function rateFor(s,date){try{date=validDate(date);}catch{return '';}const r=s.rates.filter(r=>r.date<=date).sort((a,b)=>b.date.localeCompare(a.date))[0];return r?r.rate:'';}
function add(s,v){
 if(!cycle(s))throw Error('Record opening cash received first.');v={...v,date:validDate(v.date)};
 const agent=resolveAgent(s,v.agent||v.paid_to);if(v.agent&&!agent)throw Error('Choose a master agent, or leave agent blank for another payee.');if(agent){v.agent=agent.name;v.depot=agent.depot;}
 for(const k of ['number','paid_to','particulars','words'])if(!String(v[k]||'').trim())throw Error('Required field: '+k);
 if(!['USD','LD'].includes(v.currency))throw Error('Choose USD or LD.');
 if(s.vouchers.some(r=>r.number===v.number.trim()||(v.hash&&r.hash===v.hash)))throw Error('Duplicate voucher number or photo.');
 const amount=money(v.amount);if(!amount)throw Error('Amount must be greater than zero.');
 let usd=amount,rate='';
 if(v.currency==='LD'){
  const units=decimal(v.rate,6);if(!units)throw Error('LD per USD must be positive.');rate=String(v.rate);
  // BigInt preserves exact integer arithmetic, including conversion rounding.
  usd=Number((BigInt(amount)*1000000n+BigInt(units)/2n)/BigInt(units));
 }
 if(!Number.isSafeInteger(usd)||usd>1e12)throw Error('Converted amount exceeds supported range.');
 s.vouchers.push({...v,id:s.vouchers.length+1,number:v.number.trim(),amount,rate,usd,cycle:cycle(s)});
}
function extract(t){
 const fields={number:/(?:\bP\s*C\s*[VB]\b\s*(?:no\.?|number|#)?|\bvoucher\s+(?:no\.?|number|#))\s*[:#_ -]*\s*([A-Za-z0-9/-]*\d[A-Za-z0-9/-]*)/i,date:/\bdate\s*[:_]*\s*(\d{4}-\d{2}-\d{2}|\d{1,2}\s*[-/.,\s]\s*\d{1,2}\s*[-/.,\s]\s*\d{4})/i,paid_to:/paid\s+to\s*[:._ -]*\s*([^\n]+)/i,particulars:/(?:payment\s+of|particulars|description|purpose)\s*[:._ -]*\s*([^\n]+)/i,words:/(?:the\s+sum\s+of|amount\s+in\s+words|in\s+words)\s*[:._ -]*\s*([^\n]+)/i,amount:/(?:amount\s+in\s+figures?|total\s+amount|amount\s+paid|amount)\s*[:=_ -]*\s*(?:USD|US\s*\$|LD|L\s*\$|\$)?\s*([0-9][0-9,]*(?:\.\d{1,2})?)/i};
 const v={};for(const [key,re] of Object.entries(fields)){const m=t.match(re);if(m)v[key]=key==='amount'?m[1].replaceAll(',',''):m[1].trim();}
 const amount=t.match(/amount\s+in\s+figures?\s*[:_ -]*\s*([^\n]+)/i);let source=amount&&/\bL\s*D\b|\bU\s*S\s*D\b|US\s*\$|L\s*\$/i.test(amount[1])?amount[1]:t;
 const usd=/\bU\s*S\s*D\b|U\s*S\s*\$/i.test(source),ld=/\bL\s*D\b|L\s*\$/i.test(source);if(usd!==ld)v.currency=usd?'USD':'LD';
 if(v.date){try{v.date=validDate(v.date);}catch{delete v.date;}}return v;
}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmt(n){return (n/100).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});}
function report(s,id){
 const f=s.funds.find(x=>x.id===Number(id));if(!f)throw Error('Select a valid cash cycle.');
 const rows=s.vouchers.filter(r=>r.cycle===f.id),total=rows.reduce((a,r)=>a+r.usd,0);
 const opening=s.funds.filter(r=>r.id<f.id).reduce((a,r)=>a+r.amount,0)-s.vouchers.filter(r=>r.cycle<f.id).reduce((a,r)=>a+r.usd,0);
 return '<!doctype html><html><head><meta charset="utf-8"><title>Petty Cash Summary</title><style>body{font:12px Arial;color:#102c48;margin:22px}h1{border-bottom:4px solid #087f69;padding-bottom:12px}table{width:100%;border-collapse:collapse;margin:18px 0}td,th{border:1px solid #ccd4dc;padding:7px;text-align:left;overflow-wrap:anywhere}th{background:#102c48;color:white}tr{break-inside:avoid}thead{display:table-header-group}.sign{display:flex;gap:20px;margin-top:65px;break-inside:avoid}.sign div{flex:1;border-top:1px solid;padding-top:12px}@page{size:A4 landscape;margin:12mm}@media print{body{font-size:10px;margin:0}}</style></head><body><h1>Petty Cash Summary for PrimeWay and Lollybird</h1><p>Cash cycle '+f.id+' • Receipt date '+esc(f.date)+' • Reference '+esc(f.reference)+'</p><p>Opening cash: US$ '+fmt(opening)+' | Cash received: US$ '+fmt(f.amount)+' | Expenses: US$ '+fmt(total)+' | Closing cash: US$ '+fmt(opening+f.amount-total)+'</p><table><thead><tr>'+['Date','PCV No','Paid to','Agent / depot','Particulars','Amount in words','Currency','Amount','LD per USD','USD expense'].map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+[r.date,r.number,r.paid_to,[r.agent,r.depot].filter(Boolean).join(' / '),r.particulars,r.words,r.currency,fmt(r.amount),r.rate,fmt(r.usd)].map(x=>'<td>'+esc(x)+'</td>').join('')+'</tr>').join('')+'</tbody></table><h3>Total expenses submitted: US$ '+fmt(total)+'</h3><p>Submitted to management for approval of petty cash replenishment. Requested amount: US$ '+fmt(total)+'. Final cheque amount / reference: ____________________</p><div class="sign"><div>Prepared by<br><br>Name / signature / date</div><div>Checked and verified by<br><br>Name / signature / date</div><div>Approved by<br><br>Name / signature / date</div></div><p>Petty cash summary for PrimeWay and Lollybird — expense report and supporting vouchers.</p></body></html>';
}
function csv(s){
 const cols=['Date','PCV No','Paid to','Agent','Depot','Particulars','Amount in words','Currency','Original amount','LD per USD','USD expense','Cycle','Photo'];
 const cell=v=>{let x=String(v??'');if(/^[=+\-@]/.test(x))x="'"+x;return '"'+x.replaceAll('"','""')+'"';};
 return '\ufeff'+[cols,...s.vouchers.map(r=>[r.date,r.number,r.paid_to,r.agent,r.depot,r.particulars,r.words,r.currency,(r.amount/100).toFixed(2),r.rate,(r.usd/100).toFixed(2),r.cycle,r.photo])].map(row=>row.map(cell).join(',')).join('\r\n');
}
const api={empty,money,validDate,balance,cycle,nameKey,initializeMaster,resolveAgent,addDepot,saveAgent,status,fund,setRate,rateFor,add,extract,report,csv,esc,fmt};
if(typeof module!=='undefined')module.exports=api;else global.Ledger=api;
})(typeof window!=='undefined'?window:globalThis);
