const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const dir='app/src/main/assets/',html=fs.readFileSync(dir+'index.html','utf8');
const files=[...html.matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
const c={window:null};c.window=c;c.addEventListener=()=>{};vm.createContext(c);
for(const name of files){if(name==='ui.js')break;vm.runInContext(fs.readFileSync(dir+name,'utf8'),c,{filename:name});}
assert(c.TransferData,'TransferData must exist before UI initializes');
c.L=c.Ledger;const ledger=require('./'+dir+'ledger.js');const state=ledger.empty();
c.TransferData.project(state,{transferKind:'fund',record:{uid:'database:fund:7',id:7,date:'2026-10-08',amount:10000,reference:'Imported receipt'}});
assert.equal(state.funds.length,1);assert.equal(state.funds[0].amount,10000);
console.log('PASS: actual HTML script order supports persisted import projection before UI startup');
