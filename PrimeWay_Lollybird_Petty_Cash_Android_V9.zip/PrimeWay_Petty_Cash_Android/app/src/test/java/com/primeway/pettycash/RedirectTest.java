package com.primeway.pettycash;
import java.io.IOException;
import org.junit.Test;
import static org.junit.Assert.*;
public class RedirectTest {
 @Test public void keepsCompleteGoogleResponseAddress() throws Exception {
  String url="https://script.googleusercontent.com/macros/echo?user_content_key=abc&lib=xyz";
  assertEquals(url,SharedCloud.redirect(url));
 }
 @Test public void rejectsOtherHostsCredentialsAndInsecureAddresses() throws Exception {
  String[] urls={null,"","http://script.googleusercontent.com/macros/echo","https://accounts.google.com/login","https://script.googleusercontent.com.evil.example/macros/echo","https://person@script.googleusercontent.com/macros/echo","https://script.googleusercontent.com:444/macros/echo","https://script.googleusercontent.com/macros/echo#fragment"};
  for(String url:urls){try{SharedCloud.redirect(url);fail("Accepted invalid redirect");}catch(IOException expected){}}
 }
}
