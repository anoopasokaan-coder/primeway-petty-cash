package com.primeway.pettycash;
import android.content.Context;
import android.util.Base64;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
final class CredentialStore {
 private final Context context;
 CredentialStore(Context c){context=c;}
 private javax.crypto.SecretKey key()throws Exception{
  KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
  if(!store.containsAlias("primeway-login")){KeyGenerator g=KeyGenerator.getInstance("AES","AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("primeway-login",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());g.generateKey();}
  return (javax.crypto.SecretKey)store.getKey("primeway-login",null);
 }
 void save(String value,String endpoint)throws Exception{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());c.updateAAD(endpoint.getBytes("UTF-8"));String encrypted=Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(value.getBytes("UTF-8")),Base64.NO_WRAP);if(!context.getSharedPreferences("shared",0).edit().putString("credential",encrypted).commit())throw new java.io.IOException("Cannot save sign-in.");}
 String load(String endpoint){try{String value=context.getSharedPreferences("shared",0).getString("credential","");if(value.isEmpty())return "";String[] parts=value.split(":");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.DEFAULT)));c.updateAAD(endpoint.getBytes("UTF-8"));return new String(c.doFinal(Base64.decode(parts[1],Base64.DEFAULT)),"UTF-8");}catch(Exception e){clear();return "";}}
 void clear(){context.getSharedPreferences("shared",0).edit().remove("credential").commit();}
}
