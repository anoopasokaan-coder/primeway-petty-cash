package com.primeway.pettycash;
import android.content.Context;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;

final class SharedCloud {
 private final Context context;
 private final CredentialStore credentials;
 static final String DEFAULT_ENDPOINT="https://script.google.com/macros/s/AKfycbzFBZ13BSqj0d2ntSJcn6FM2BL_0wu-k8F1oRz6BBdhCU5g7Npx8mdKz8wYGUb_GvLs/exec";
 private volatile String endpoint="",token="";
 SharedCloud(Context c){context=c;credentials=new CredentialStore(c);endpoint=c.getSharedPreferences("shared",0).getString("endpoint",DEFAULT_ENDPOINT);token=credentials.load(endpoint);}
 boolean signedIn(){return !token.isEmpty();}
 JSONObject analyze(File photo)throws Exception{
  JSONObject q=new JSONObject();q.put("action","ocr.start");try(InputStream in=new FileInputStream(photo)){q.put("image",Base64.encodeToString(read(in,4000000),Base64.NO_WRAP));}
  JSONObject r=request(q);if(!r.optBoolean("ok"))throw new IOException(r.optString("error"));String job=r.getString("job");
  long deadline=System.currentTimeMillis()+120000;
  while(System.currentTimeMillis()<deadline){Thread.sleep(1800);q=new JSONObject();q.put("action","ocr.poll");q.put("job",job);r=request(q);if(!r.optBoolean("ok"))throw new IOException(r.optString("error"));if(r.has("analysis"))return r.getJSONObject("analysis");}
  throw new IOException("Azure reading timed out. Check before retrying.");
 }
 String endpoint(){return endpoint;}
 String configure(String url,String code)throws Exception{
  URI uri=new URI(url.trim());if(!"https".equals(uri.getScheme())||!"script.google.com".equals(uri.getHost())||!uri.getPath().matches("/macros/s/[A-Za-z0-9_-]+/exec")||uri.getQuery()!=null||uri.getFragment()!=null||uri.getUserInfo()!=null||(uri.getPort()!=-1&&uri.getPort()!=443))throw new IOException("Use the Google Apps Script deployment URL ending /exec.");
  if(!code.trim().matches("[A-Fa-f0-9]{64}"))throw new IOException("Enter your personal 64-character access code.");
  credentials.clear();endpoint=url.trim();token=code.trim();context.getSharedPreferences("shared",0).edit().putString("endpoint",endpoint).apply();return "OK";
 }
 void signOut(){token="";credentials.clear();}
 JSONObject request(JSONObject q)throws Exception{
  if(token.isEmpty())throw new IOException("Sign in to shared cash before saving.");q.put("token",token);
  if("sync.voucher".equals(q.optString("action"))){
   JSONObject v=q.getJSONObject("voucher"),media=new JSONObject();
   if("add".equals(q.optString("kind"))){attach(media,"photo",new File(context.getFilesDir()+"/photos/",safe(v.optString("photo"))));attach(media,"note",new File(context.getFilesDir()+"/notes/",safe(v.optString("voiceNote"))));}q.put("attachments",media);
  }
  if("save".equals(q.optString("action"))){
   JSONArray vouchers=q.getJSONObject("state").getJSONArray("vouchers");JSONObject media=new JSONObject();
   for(int i=0;i<vouchers.length();i++){JSONObject v=vouchers.getJSONObject(i);if(!v.has("createdBy")){
    attach(media,"photo",new File(context.getFilesDir()+"/photos/",safe(v.optString("photo"))));
    attach(media,"note",new File(context.getFilesDir()+"/notes/",safe(v.optString("voiceNote"))));
   }}q.put("attachments",media);
  }
  byte[] data=q.toString().getBytes("UTF-8");if(data.length>16000000)throw new IOException("Request too large. Use a smaller photo or shorter note.");
  JSONObject result=new JSONObject(exchange(data));
   if("attachment".equals(q.optString("action"))&&result.optBoolean("ok")){
    String name=safe(q.getString("name")),kind=q.optString("kind");if(name.isEmpty()||!("photo".equals(kind)||"note".equals(kind)))throw new IOException("Invalid attachment.");
    File dir=new File(context.getFilesDir(),"photo".equals(kind)?"photos":"notes");dir.mkdirs();File target=new File(dir,name);
    byte[] bytes=Base64.decode(result.getString("data"),Base64.DEFAULT);try(FileOutputStream out=new FileOutputStream(target)){out.write(bytes);}result.remove("data");result.put("name",name);
   }
   if(result.optBoolean("ok")&&"load".equals(q.optString("action")))credentials.save(token,endpoint);
   return result;
 }
 private HttpURLConnection connection(String address,String method)throws IOException{
  HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();
  c.setConnectTimeout(20000);c.setReadTimeout(90000);c.setInstanceFollowRedirects(false);
  c.setRequestMethod(method);c.setRequestProperty("Accept","application/json");return c;
 }
 static String redirect(String location)throws IOException{
  try{URI u=new URI(location==null?"":location);
   if(!"https".equals(u.getScheme())||!"script.googleusercontent.com".equals(u.getHost())||u.getUserInfo()!=null||(u.getPort()!=-1&&u.getPort()!=443)||u.getFragment()!=null||!u.getPath().startsWith("/macros/"))throw new IOException("Google redirected outside the shared response service. Check the /exec URL and deployment access (Anyone).");
   return u.toString();
  }catch(URISyntaxException e){throw new IOException("Google returned an invalid redirect. Local entries retained.");}
 }
 private String response(HttpURLConnection c,int status)throws IOException{
  if(status!=200)throw new IOException("Shared service returned HTTP "+status+". Local entries retained.");
  try(InputStream in=c.getInputStream()){
   String body=new String(read(in,20000000),"UTF-8");
   if(!body.trim().startsWith("{"))throw new IOException("Google returned a web page instead of JSON. Check the /exec deployment URL and access. Local entries retained.");
   return body;
  }
 }
 private String exchange(byte[] data)throws IOException{
  String location;HttpURLConnection c=connection(endpoint,"POST");
  try{
   c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");c.setFixedLengthStreamingMode(data.length);
   try(OutputStream out=c.getOutputStream()){out.write(data);}
   int status=c.getResponseCode();
   if(status!=301&&status!=302&&status!=303)return response(c,status);
   location=redirect(c.getHeaderField("Location"));
  }catch(javax.net.ssl.SSLException e){throw new IOException("Secure connection to Google failed. Local entries retained. Refresh before retrying a save.",e);}
   catch(SocketTimeoutException e){throw new IOException("Google request timed out. Local entries retained. Refresh before retrying a save.",e);}
   catch(SocketException e){throw new IOException("Google connection was interrupted. Local entries retained. Refresh before retrying a save.",e);}
  finally{c.disconnect();}
  // Retrieve the existing response only. Never automatically resend a financial POST.
  int hops=0,attempts=0;
  while(true){c=connection(location,"GET");
   try{int status=c.getResponseCode();
    if(status==301||status==302||status==303){if(++hops>3)throw new IOException("Too many Google response redirects. Local entries retained.");location=redirect(c.getHeaderField("Location"));continue;}
    return response(c,status);
   }catch(javax.net.ssl.SSLException|SocketTimeoutException|SocketException e){
    if(++attempts>=2)throw new IOException("Unable to download Google’s response. Local entries retained; synchronize again when the connection is stable.",e);
   }finally{c.disconnect();}
  }
 }
 private String safe(String name)throws IOException{if(!name.isEmpty()&&!name.matches("[A-Za-z0-9_.-]+"))throw new IOException("Invalid attachment name.");return name;}
 private void attach(JSONObject o,String key,File file)throws Exception{if(file.isFile())try(InputStream in=new FileInputStream(file)){o.put(key,Base64.encodeToString(read(in,8000000),Base64.NO_WRAP));}}
 private byte[] read(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new IOException("Attachment/response too large.");out.write(buf,0,n);}return out.toByteArray();}
}
