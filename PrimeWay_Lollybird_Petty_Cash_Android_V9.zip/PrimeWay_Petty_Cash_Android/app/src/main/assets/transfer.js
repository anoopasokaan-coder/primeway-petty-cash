'use strict';
(function(global){
const FIELDS={voucher:['uid','number','date','paid_to','agent','depot','particulars','words','currency','amount','rate','usd','cycle'],fund:['uid','id','date','amount','reference'],rate:['date','rate']};
const clone=x=>JSON.parse(JSON.stringify(x));
const business=(kind,r)=>Object.fromEntries(FIELDS[kind].map(k=>[k,r[k]===undefined?'':r[k]]));
const comparable=(kind,r)=>{const v=business(kind,r);if(kind==='fund')delete v.id;return JSON.stringify(v);};
const uid=(kind,r,db)=>kind==='rate'?db+':rate:'+r.date:r.uid;
function validate(kind,r){
 if(kind!=='rate'&&(!/^[A-Za-z0-9_:-]{10,180}$/.test(r.uid||'')))throw Error('Permanent record ID missing. Refresh once using the V9 Google code before exporting.');
 if(L.validDate(r.date)!==r.date)throw Error('Invalid transfer date.');
 if(kind==='rate'){if(!/^\d+(\.\d{1,6})?$/.test(r.rate)||Number(r.rate)<=0)throw Error('Invalid rate.');return;}
 if(!Number.isSafeInteger(r.amount)||r.amount<=0||r.amount>1e12)throw Error('Invalid transferred amount.');
 if(kind==='fund'){if(!Number.isInteger(r.id)||r.id<1||typeof r.reference!=='string'||!r.reference.trim()||r.reference.length>2000)throw Error('Invalid cash receipt.');return;}
 for(const k of ['number','paid_to','particulars','words'])if(typeof r[k]!=='string'||!r[k].trim()||r[k].length>2000)throw Error('Invalid voucher '+k+'.');
 if(!['USD','LD'].includes(r.currency)||!Number.isInteger(r.cycle)||r.cycle<1)throw Error('Invalid voucher currency/cycle.');
 let expected=r.amount;if(r.currency==='LD'){if(!/^\d+(\.\d{1,6})?$/.test(r.rate)||Number(r.rate)<=0)throw Error('Invalid LD rate.');const parts=r.rate.split('.'),units=BigInt(parts[0])*1000000n+BigInt((parts[1]||'').padEnd(6,'0'));expected=Number((BigInt(r.amount)*1000000n+units/2n)/units);}
 if(!Number.isSafeInteger(r.usd)||r.usd!==expected)throw Error('Transferred USD conversion does not match.');
 if(typeof InputHelpers!=='undefined'){let amount;try{amount=InputHelpers.number(r.words.replace(/\bonly\b/gi,''));}catch{}if(amount!==undefined&&L.money(amount)!==r.amount)throw Error('Transferred amount in words differs.');}
}
function records(s){return [['fund',s.funds],['rate',s.rates],['voucher',s.vouchers]].flatMap(([kind,rows])=>rows.map(r=>({kind,record:business(kind,r)})));}
function bundle(s,db,source){if(!db)throw Error('Refresh online once with the V9 Google code before file transfers.');const items=records(s);items.forEach(x=>validate(x.kind,x.record));return {format:'primeway-database-transfer',version:9,databaseId:db,createdAt:new Date().toISOString(),source:String(source||'').slice(0,100),records:items};}
function plan(file,state,db){
 if(!db||file.format!=='primeway-database-transfer'||file.version!==9||file.databaseId!==db||!Array.isArray(file.records)||file.records.length>100000)throw Error('Wrong transfer format/version/database. Import only V9 transfer files for this shared ledger.');
 const current=new Map(records(state).map(x=>[uid(x.kind,x.record,db),x]));const seen=new Set();let duplicates=0;const items=[];
 for(const x of file.records){if(!FIELDS[x.kind]||!x.record||typeof x.record!=='object')throw Error('Invalid transfer record.');const r=business(x.kind,x.record);validate(x.kind,r);const key=uid(x.kind,r,db);if(seen.has(key))throw Error('Duplicate permanent ID inside this file.');seen.add(key);
 const old=current.get(key);if(old&&comparable(x.kind,old.record)===comparable(x.kind,r)){duplicates++;continue;}
 const norm=n=>String(n).toLowerCase().replace(/[^a-z0-9]/g,'').replace(/^0+/,'');const collision=!old&&[...current.values()].some(y=>y.kind===x.kind&&(x.kind==='voucher'&&norm(y.record.number)===norm(r.number)||x.kind==='fund'&&y.record.id===r.id));
 items.push({kind:x.kind,record:r,base:old?old.record:null,conflict:!!old,blocked:collision||(x.kind==='fund'&&!!old),source:String(file.source||'Unknown (unverified)').slice(0,100)});
 }
 return {items,duplicates,source:String(file.source||'Unknown (unverified)').slice(0,100)};
}
function project(s,op){
 const kind=op.transferKind,r=op.record;validate(kind,r);
 if(kind==='rate'){const prior=s.rates.find(x=>x.date===r.date);if(prior)Object.assign(prior,r);else s.rates.push(clone(r));return;}
 const rows=kind==='fund'?s.funds:s.vouchers;const old=rows.find(x=>x.uid===r.uid);
 if(old){if(kind==='voucher')Object.assign(old,r);return;}
 if(kind==='fund'){s.funds.push(clone(r));s.funds.sort((a,b)=>a.id-b.id);return;}
 rows.push({...clone(r),id:op.localId,photo:'',hash:'',voiceNote:'',reviewed:true});
}
const api={FIELDS,business,comparable,validate,records,bundle,plan,project,uid};if(typeof module!=='undefined')module.exports=api;else global.TransferData=api;
})(typeof window!=='undefined'?window:globalThis);

if(typeof window!=='undefined'){
window.onTransferFile=file=>{try{if(file.error)throw Error(file.error);TransferUI.review(JSON.parse(file.data));}catch(e){native().warning(e.message);}};
const TransferUI={
 guard(){if(Offline.syncing||Shared.pending.size)throw Error('Wait for the current request to finish.');if(!Offline.data?.server.databaseId)throw Error('Refresh online once after updating the Google code to V9.');},
 export(includePhotos){this.guard();const file=TransferData.bundle(state,Offline.data.server.databaseId,Shared.user?.name);if(includePhotos){file.photos={};for(const r of state.vouchers)if(r.photo){const bytes=native().transferPhoto(r.photo);if(bytes.startsWith('ERROR:'))throw Error(bytes);file.photos[r.uid]=bytes;}}const json=JSON.stringify(file);if(json.length>32000000)throw Error('Transfer exceeds 32 MB. Use database-only export; send large photos separately.');native().exportTransfer(json);},
 review(file){this.guard();if(!['admin','editor'].includes(Shared.user?.role))throw Error('Admin or Editor required to import entries.');const p=TransferData.plan(file,state,Offline.data.server.databaseId);this.file=file;this.plan=p;
 const box=$('transferReview');box.hidden=false;box.innerHTML='<h3>Review database import</h3><p>'+p.duplicates+' identical records skipped. Source: '+L.esc(p.source)+' (file-declared, unverified).</p><p>New records are selected. Conflicting corrections require your explicit selection. Cash receipt differences cannot be overwritten.</p>'+p.items.map((x,i)=>'<div class="entry"><label><input type="checkbox" style="width:auto" data-import="'+i+'" '+(!x.conflict?'checked':'')+' '+(x.blocked||x.kind!=='voucher'&&Shared.user.role!=='admin'?'disabled':'')+'> '+L.esc(x.kind)+' '+L.esc(x.record.number||x.record.reference||x.record.date)+' · '+(x.blocked?'BLOCKED — duplicate ID/number or cash difference':x.conflict?'CONFLICT — review':'New')+'</label><pre style="white-space:pre-wrap">Incoming: '+L.esc(JSON.stringify(x.record))+(x.base?'\nCurrent: '+L.esc(JSON.stringify(x.base)):'')+'</pre></div>').join('')+'<label><input id="receivePhotos" type="checkbox" style="width:auto"> Include optional photos supplied in this file</label><button id="confirmImport">Import selected records</button><button id="cancelImport">Cancel</button>';
 $('cancelImport').onclick=()=>{box.hidden=true;box.innerHTML='';};$('confirmImport').onclick=()=>{try{this.commit();box.hidden=true;}catch(e){native().warning(e.message);}};
 },
 commit(){this.guard();const next=Offline.clone(Offline.data);const selected=[...$('transferReview').querySelectorAll('[data-import]:checked:not(:disabled)')].map(el=>this.plan.items[Number(el.dataset.import)]);if(!selected.length)throw Error('No new records selected.');
 for(const x of selected){const key=TransferData.uid(x.kind,x.record,next.server.databaseId);if(next.queue.some(o=>o.kind==='transfer'&&TransferData.uid(o.transferKind,o.record,next.server.databaseId)===key||o.voucher?.uid===key))throw Error('A local change for this record is already pending. Synchronize or resolve it first.');}
 const backup=native().transferRecovery(JSON.stringify(next));if(backup!=='OK')throw Error(backup);
 next.media=next.media||{};
 for(const x of selected){const op={operationId:'transfer_'+Date.now()+'_'+Math.random().toString(36).slice(2),kind:'transfer',transferKind:x.kind,record:x.record,base:x.base,source:x.source,localId:-Date.now()-Math.floor(Math.random()*100000),error:''};next.queue.push(op);
 if($('receivePhotos').checked&&this.file.photos?.[x.record.uid]){const name=native().saveTransferPhoto(this.file.photos[x.record.uid]);if(name.startsWith('ERROR:'))throw Error(name);next.media[x.record.uid]={photo:name};}}
 Offline.persist(next);Offline.project();render();Shared.paint();native().warning(selected.length+' records imported locally. '+this.plan.duplicates+' duplicates skipped. Use Synchronize now when online. Google has not yet confirmed these imported changes.');
 }
};
window.addEventListener('DOMContentLoaded',()=>{$('transferExport').onclick=()=>{try{TransferUI.export(false);}catch(e){native().warning(e.message);}};$('transferPhotos').onclick=()=>{try{TransferUI.export(true);}catch(e){native().warning(e.message);}};$('transferImport').onclick=()=>{try{TransferUI.guard();native().pickTransfer();}catch(e){native().warning(e.message);}};});
}
