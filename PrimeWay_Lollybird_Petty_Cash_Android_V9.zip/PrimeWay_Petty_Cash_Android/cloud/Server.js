/* Google Apps Script V8. Append the supplied Ledger.gs in the same project. */
function setupPrimeWay() {
 const p=PropertiesService.getScriptProperties();if(p.getProperty('DATABASE_ID'))throw Error('Already initialized.');
 const folder=DriveApp.createFolder('PrimeWay Lollybird Shared Petty Cash');
 const token=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');
 const db={revision:0,state:Ledger.empty(),users:[{id:Utilities.getUuid(),name:'Administrator',role:'admin',active:true,tokenHash:hashToken(token)}],audit:[]};
 Ledger.initializeMaster(db.state,AGENTS);
 const file=folder.createFile('database.json',JSON.stringify(db),'application/json');
 p.setProperties({DATABASE_ID:file.getId(),FOLDER_ID:folder.getId()});
 console.log('PRIVATE ADMIN ACCESS CODE (keep secret): '+token);console.log('Drive folder: '+folder.getUrl());
}
function hashToken(t){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(t)).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');}
function same(a,b){return stable(a)===stable(b);}
function stable(v){if(Array.isArray(v))return '['+v.map(stable).join(',')+']';if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}';return JSON.stringify(v);}
function publicUser(u){return {id:u.id,name:u.name,role:u.role,active:u.active};}
function transition(old,next,user){
 const s=JSON.parse(JSON.stringify(old));
 const allowed=['version','threshold','funds','vouchers','rates','masterVersion','agents','depots'];
 if(Object.keys(next).some(k=>!allowed.includes(k))||next.version!==1||next.masterVersion!==1)throw Error('Invalid ledger schema.');
 const changed=allowed.filter(k=>!same(old[k],next[k]));if(changed.length!==1&&!(changed.length===2&&changed.includes('agents')&&changed.includes('depots')))throw Error('Save one change at a time.');
 let action='';
 if(changed.includes('vouchers')){
  if(!['admin','editor','entry'].includes(user.role))throw Error('Your role cannot enter vouchers.');
  if(next.vouchers.length===old.vouchers.length+1&&same(next.vouchers.slice(0,-1),old.vouchers)){
   const v=next.vouchers[next.vouchers.length-1];validateVoucher(v);if(!v.reviewed)throw Error('Review all voucher fields before saving.');
   Ledger.add(s,{...v,amount:(v.amount/100).toFixed(2)});action='voucher.add';
  }else if(next.vouchers.length===old.vouchers.length&&['admin','editor'].includes(user.role)){
   const diffs=next.vouchers.map((v,i)=>same(v,old.vouchers[i])?-1:i).filter(i=>i>=0);if(diffs.length!==1)throw Error('Edit one voucher at a time.');
   const i=diffs[0],v=next.vouchers[i],previous=old.vouchers[i];validateVoucher(v);for(const k of ['photo','hash','voiceNote','cloudPhoto','cloudNote','createdBy','createdAt','updatedBy','updatedAt'])if(!same(v[k],previous[k]))throw Error('Source attachments and audit metadata cannot be changed.');if(!v.reviewed||v.id!==previous.id)throw Error('Invalid voucher edit.');
   Ledger.edit(s,v.id,{...v,amount:(v.amount/100).toFixed(2)});action='voucher.edit';
  }else throw Error('Your role cannot edit or remove saved vouchers.');
 }else{
  if(user.role!=='admin')throw Error('Only Admin can change cash, rates, agents, depots or settings.');
  if(changed[0]==='funds'&&next.funds.length===old.funds.length+1&&same(next.funds.slice(0,-1),old.funds)){
   const f=next.funds[next.funds.length-1];Ledger.fund(s,{...f,amount:(f.amount/100).toFixed(2)});action='cash.receive';
  }else if(changed[0]==='threshold'){s.threshold=Ledger.money((next.threshold/100).toFixed(2));action='threshold.change';
  }else if(changed[0]==='rates'){
   const differences=next.rates.filter(r=>!old.rates.some(x=>same(x,r)));if(differences.length!==1)throw Error('Change one rate at a time.');Ledger.setRate(s,differences[0].date,differences[0].rate);action='rate.change';
  }else if(changed[0]==='depots'&&next.depots.length===old.depots.length+1){const d=next.depots.find(x=>!old.depots.includes(x));Ledger.addDepot(s,d);action='depot.add';
  }else if(changed.includes('agents')){
   const diffs=next.agents.filter(a=>!old.agents.some(x=>same(x,a)));if(diffs.length!==1)throw Error('Change one agent at a time.');
   const removed=old.agents.filter(a=>!next.agents.some(x=>same(x,a)));if(removed.length>1)throw Error('Invalid agent change.');
   const a=diffs[0];Ledger.saveAgent(s,{...a,old_name:removed[0]?.name||''});action='agent.change';
  }else throw Error('Unsupported change.');
 }
 if(!same(s,next))throw Error('Validation failed: unexpected or inconsistent fields. Refresh and review.');
 return {state:s,action};
}
function validateVoucher(v){
 const keys=['number','date','paid_to','agent','depot','particulars','words','currency','amount','rate','photo','hash','voiceNote','reviewed','id','usd','cycle','cloudPhoto','cloudNote','createdBy','createdAt','updatedBy','updatedAt','uid'];
 if(Object.keys(v).some(k=>!keys.includes(k)))throw Error('Unknown voucher field.');
 for(const k of ['number','paid_to','particulars','words'])if(typeof v[k]!=='string'||v[k].length>2000)throw Error('Invalid voucher text.');
 let words;try{words=InputHelpers.number(v.words.replace(/\bonly\b/gi,''));}catch{}
 if(words!==undefined&&Ledger.money(words)!==v.amount)throw Error('Amount in figures and words differ. Correct the voucher before saving.');
}
function doPost(e){
 const lock=LockService.getScriptLock();let locked=false;
 try{
  if(!e?.postData?.contents||e.postData.contents.length>16000000)throw Error('Request missing or too large.');
  const q=JSON.parse(e.postData.contents);if(!/^[a-f0-9]{64}$/i.test(q.token||''))throw Error('Access denied.');
  lock.waitLock(25000);locked=true;
  const p=PropertiesService.getScriptProperties(),file=DriveApp.getFileById(p.getProperty('DATABASE_ID')),db=JSON.parse(file.getBlob().getDataAsString());
  const u=db.users.find(x=>x.active&&x.tokenHash===hashToken(q.token));if(!u)throw Error('Access denied: wrong or revoked access code.');
  if(ensureTransferIds(db,p))file.setContent(JSON.stringify(db));
  const response=()=>({ok:true,databaseId:db.databaseId,revision:db.revision,state:db.state,user:publicUser(u),users:u.role==='admin'?db.users.map(publicUser):[],reader:readerSettings(),audit:u.role==='admin'?db.audit.slice(-100):[]});
  if(q.action==='load')return output(response());
  if(q.action==='ocr.start'||q.action==='ocr.poll'){lock.releaseLock();locked=false;return output(azureRead(q,u));}
  if(q.action==='reader.settings'){
   if(u.role!=='admin')throw Error('Admin required.');
   const endpoint=azureEndpoint(q.endpoint);const key=String(q.key||'').trim();
   if(key&&!/^[A-Za-z0-9_-]{16,256}$/.test(key))throw Error('Invalid Azure key.');
   if(q.enabled&&!key&&!p.getProperty('AZURE_KEY'))throw Error('Enter the Azure key.');
   p.setProperty('AZURE_ENDPOINT',endpoint);if(key)p.setProperty('AZURE_KEY',key);p.setProperty('AZURE_ENABLED',q.enabled?'true':'false');
   return output(response());
  }
  if(q.action==='attachment'){
   const refs=db.state.vouchers.flatMap(v=>[v.cloudPhoto,v.cloudNote]).filter(Boolean);if(!refs.includes(q.fileId))throw Error('Attachment not in this database.');
   const blob=DriveApp.getFileById(q.fileId).getBlob();return output({ok:true,data:Utilities.base64Encode(blob.getBytes())});
  }
  if(q.action==='sync.transfer'){
   const changed=applyTransfer(db,q,u);
   if(changed){const prior=file.getBlob();DriveApp.getFolderById(p.getProperty('FOLDER_ID')).createFile(Utilities.newBlob(prior.getBytes(),'application/json','revision_'+db.revision+'.json'));db.revision++;db.audit.push({revision:db.revision,at:new Date().toISOString(),by:u.name,action:'transfer.'+q.kind,declaredSource:String(q.source||'').slice(0,100)});file.setContent(JSON.stringify(db));}
   return output({...response(),operationId:q.operationId});
  }
  if(q.action==='sync.voucher'){
   if(!/^[A-Za-z0-9_-]{10,100}$/.test(q.operationId||''))throw Error('Invalid sync operation.');
   db.syncReceipts=db.syncReceipts||{};
   const receipt=db.syncReceipts[q.operationId];
   if(receipt){
    let matches=receipt.payload===stable({kind:q.kind,voucher:q.voucher,base:q.base});
    if(!matches){try{const prior=JSON.parse(receipt.payload.replace(/:undefined(?=[,}])/g,':null'));const clean=v=>{if(!v)return null;const r=transferBusiness('voucher',v);delete r.uid;return r;};matches=prior.kind===q.kind&&same(clean(prior.voucher),clean(q.voucher))&&same(clean(prior.base),clean(q.base));}catch{}}
    if(receipt.user!==u.id||!matches)throw Error('Sync operation identity mismatch.');return output({...response(),operationId:q.operationId});
   }
   if(q.kind==='add'&&q.voucher.uid){
    const current=db.state.vouchers.find(v=>v.uid===q.voucher.uid);
    if(current){const claimed={...q.voucher,amount:Ledger.money(q.voucher.amount),date:Ledger.validDate(q.voucher.date),usd:current.usd};if(!same(transferBusiness('voucher',current),transferBusiness('voucher',claimed)))throw Error('Transferred voucher differs from this pending entry. Review before retrying.');return output({...response(),operationId:q.operationId});}
   }
   const candidate=JSON.parse(JSON.stringify(db.state));
   if(q.kind==='add'){if(q.voucher.cycle!==Ledger.cycle(db.state))throw Error('Conflict: cash was replenished since entry. Pending voucher retained; ask Admin to review its cash cycle.');Ledger.add(candidate,q.voucher);}
   else if(q.kind==='edit'){
    const current=db.state.vouchers.find(v=>v.id===q.base?.id);
    if(!current||!same(transferBusiness('voucher',current),transferBusiness('voucher',q.base)))throw Error('Conflict: this voucher changed on another device. Pending correction retained; review before retrying.');
    Ledger.edit(candidate,current.id,q.voucher);
   }else throw Error('Invalid sync kind.');
   q.state=candidate;q.action='save';q.revision=db.revision;
  }
  if(q.revision!==db.revision)return output({ok:false,conflict:true,error:'Another user saved a change. Your form is kept. Refresh shared data and retry.'});
  let action,issuedToken;
  if(q.action==='save'){
   const t=transition(db.state,q.state,u);action=t.action;
   // Existing media references cannot be changed by an edit. New attachments are validated and private.
   if(action==='voucher.add'){
    const v=t.state.vouchers[t.state.vouchers.length-1];if(v.cloudPhoto||v.cloudNote||v.createdBy)throw Error('Invalid new attachment metadata.');
    const folder=DriveApp.getFolderById(p.getProperty('FOLDER_ID'));
    for(const [key,field,mime] of [['photo','cloudPhoto','image/jpeg'],['note','cloudNote','audio/mp4']]){
     const data=q.attachments?.[key];if(v[key==='photo'?'photo':'voiceNote']&&!data)throw Error('Attachment missing. Please retry.');
     if(data){if(typeof data!=='string'||data.length>11000000||!/^[A-Za-z0-9+/=]+$/.test(data))throw Error('Attachment too large or invalid.');
      const blob=Utilities.newBlob(Utilities.base64Decode(data),mime,'PCV_'+v.number.replace(/[^A-Za-z0-9_-]/g,'_')+'_'+Utilities.getUuid()+(key==='photo'?'.jpg':'.m4a'));
      v[field]=folder.createFile(blob).getId();
     }
    }
    v.createdBy=u.name;v.createdAt=new Date().toISOString();
   }
   if(action==='voucher.edit'){const v=t.state.vouchers.find((v,i)=>!same(v,db.state.vouchers[i]));v.updatedBy=u.name;v.updatedAt=new Date().toISOString();}
   db.state=t.state;
   if(action==='voucher.add'&&q.operationId&&!db.state.vouchers[db.state.vouchers.length-1].uid)db.state.vouchers[db.state.vouchers.length-1].uid='op:'+q.operationId;
   ensureTransferIds(db,p);
   if(q.operationId){db.syncReceipts[q.operationId]={user:u.id,payload:stable({kind:q.kind,voucher:q.voucher,base:q.base})};}
  }else if(q.action==='user.add'){
   if(u.role!=='admin')throw Error('Admin required.');const name=String(q.name||'').trim();if(!name||name.length>100||!['admin','editor','entry','viewer'].includes(q.role))throw Error('Enter name and valid role.');
   if(db.users.some(x=>x.active&&x.name.toLowerCase()===name.toLowerCase()))throw Error('User name already exists.');
   issuedToken=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');db.users.push({id:Utilities.getUuid(),name,role:q.role,active:true,tokenHash:hashToken(issuedToken)});action='user.add';
  }else if(q.action==='user.update'){
   if(u.role!=='admin')throw Error('Admin required.');const target=db.users.find(x=>x.id===q.userId);if(!target||!['admin','editor','entry','viewer'].includes(q.role)||typeof q.active!=='boolean')throw Error('Invalid user change.');
   if(target.id===u.id)throw Error('Ask another admin to change your own account.');
   if(target.role==='admin'&&target.active&&(q.role!=='admin'||!q.active)&&db.users.filter(x=>x.active&&x.role==='admin').length<=1)throw Error('Keep at least one active admin.');
   target.role=q.role;target.active=q.active;action='user.update';
  }else throw Error('Unknown operation.');
  const prior=file.getBlob();DriveApp.getFolderById(p.getProperty('FOLDER_ID')).createFile(Utilities.newBlob(prior.getBytes(),'application/json','revision_'+db.revision+'.json'));
  db.revision++;db.audit.push({revision:db.revision,at:new Date().toISOString(),by:u.name,action});if(db.audit.length>2000)db.audit=db.audit.slice(-2000);
  file.setContent(JSON.stringify(db));return output({...response(),issuedToken,operationId:q.operationId});
 }catch(err){return output({ok:false,error:String(err.message||err)});}finally{if(locked)lock.releaseLock();}
}
function output(value){return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);}

function azureEndpoint(value){const s=String(value||'').trim().replace(/\/$/,'');if(!/^https:\/\/[A-Za-z0-9-]+\.(cognitiveservices\.azure\.com|services\.ai\.azure\.com)$/.test(s))throw Error('Use the Azure resource HTTPS endpoint.');return s;}
function readerSettings(){const p=PropertiesService.getScriptProperties();return {endpoint:p.getProperty('AZURE_ENDPOINT')||'https://primeway.cognitiveservices.azure.com',enabled:p.getProperty('AZURE_ENABLED')!=='false'&&!!p.getProperty('AZURE_KEY'),configured:!!p.getProperty('AZURE_KEY')};}
function azureRead(q,u){
 if(!['admin','editor','entry'].includes(u.role))throw Error('Your role cannot read new vouchers.');
 const p=PropertiesService.getScriptProperties(),settings=readerSettings(),endpoint=azureEndpoint(settings.endpoint),key=p.getProperty('AZURE_KEY');if(!settings.enabled)throw Error('Azure reader is not configured. Ask your administrator to edit reader settings.');
 const cache=CacheService.getScriptCache();let job,operation;
 if(q.action==='ocr.start'){
  if(typeof q.image!=='string'||q.image.length>5400000||!/^[A-Za-z0-9+/=]+$/.test(q.image))throw Error('Photo invalid or too large (maximum 4 MB).');
  const bytes=Utilities.base64Decode(q.image);if(bytes.length>4000000||bytes.length<3||((bytes[0]+256)%256)!==255||((bytes[1]+256)%256)!==216)throw Error('Upload a JPEG photo under 4 MB.');
  const r=UrlFetchApp.fetch(endpoint+'/documentintelligence/documentModels/prebuilt-read:analyze?api-version=2024-11-30',{method:'post',contentType:'application/octet-stream',payload:bytes,headers:{'Ocp-Apim-Subscription-Key':key},muteHttpExceptions:true,followRedirects:false});
  if(r.getResponseCode()!==202)throw Error('Azure returned HTTP '+r.getResponseCode()+'. Check settings or request limits.');
  const headers=r.getAllHeaders();operation=headers['Operation-Location']||headers['operation-location'];
  if(typeof operation!=='string'||!operation.startsWith(endpoint+'/documentintelligence/'))throw Error('Unexpected Azure result address.');
  job=Utilities.getUuid();cache.put('ocr:'+job,JSON.stringify({user:u.id,operation}),300);return {ok:true,job};
 }
 job=String(q.job||'');if(!/^[A-Za-z0-9-]{1,100}$/.test(job))throw Error('Invalid reading job.');const saved=cache.get('ocr:'+job);if(!saved)throw Error('Reading job expired. Take or select the photo again.');const entry=JSON.parse(saved);if(entry.user!==u.id)throw Error('Reading job belongs to another user.');operation=entry.operation;
 if(!operation.startsWith(endpoint+'/documentintelligence/'))throw Error('Reader settings changed. Restart reading.');
 const r=UrlFetchApp.fetch(operation,{headers:{'Ocp-Apim-Subscription-Key':key},muteHttpExceptions:true,followRedirects:false});if(r.getResponseCode()!==200)throw Error('Azure returned HTTP '+r.getResponseCode()+'.');const result=JSON.parse(r.getContentText());
 if(result.status==='succeeded'){cache.remove('ocr:'+job);return {ok:true,analysis:result.analyzeResult};}if(['failed','canceled'].includes(result.status)){cache.remove('ocr:'+job);throw Error('Azure could not read this photo.');}return {ok:true,pending:true};
}

function authorizeExternalAccess() {
 UrlFetchApp.fetch('https://www.google.com',{muteHttpExceptions:true});
 console.log('External request permission is ready.');
}
