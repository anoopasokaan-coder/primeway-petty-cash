// V9 database-only transfer. Imported origins are declared by the file, not authenticated.
function transferBusiness(kind,r){
 const fields=kind==='voucher'?['uid','number','date','paid_to','agent','depot','particulars','words','currency','amount','rate','usd','cycle']:kind==='fund'?['uid','date','amount','reference']:['date','rate'];
 const out={};for(const k of fields)out[k]=r[k]===undefined?'':r[k];return out;
}
function ensureTransferIds(db,p){
 let changed=false;const id=db.databaseId||hashToken(p.getProperty('DATABASE_ID'));if(!db.databaseId){db.databaseId=id;changed=true;}
 for(const [kind,rows] of [['v',db.state.vouchers],['f',db.state.funds]])for(const r of rows)if(!r.uid){r.uid=id+':'+kind+':'+r.id;changed=true;}
 return changed;
}
function applyTransfer(db,q,u){
 if(!['admin','editor'].includes(u.role))throw Error('Admin or Editor required to import transferred records.');
 if(q.databaseId!==db.databaseId)throw Error('Transfer belongs to another database.');
 if(!/^[A-Za-z0-9_:-]{10,180}$/.test(q.operationId||'')||!['voucher','fund','rate'].includes(q.kind)||!q.record||typeof q.record!=='object')throw Error('Invalid transfer operation.');
 const kind=q.kind,r=transferBusiness(kind,q.record),payload=stable({kind,record:r,base:q.base?transferBusiness(kind,q.base):null});
 db.transferReceipts=db.transferReceipts||{};
 const prior=db.transferReceipts[q.operationId];if(prior){if(prior!==payload)throw Error('Transfer operation identity mismatch.');return false;}
 if(kind!=='rate'&&!/^[A-Za-z0-9_:-]{10,180}$/.test(r.uid||''))throw Error('Permanent record ID missing.');
 const rows=kind==='voucher'?db.state.vouchers:kind==='fund'?db.state.funds:db.state.rates;
 let current=rows.find(x=>kind==='rate'?x.date===r.date:x.uid===r.uid);
 if(current&&same(transferBusiness(kind,current),r)){db.transferReceipts[q.operationId]=payload;return true;}
 if(current){
  if(kind==='fund')throw Error('Cash receipt differs. Do not overwrite cash receipts; ask Admin to reconcile.');
  if(!q.base||!same(transferBusiness(kind,current),transferBusiness(kind,q.base)))throw Error('Conflict: shared record changed. Review the imported correction against current shared data.');
 }
 if(kind==='voucher'){
  if(!Number.isSafeInteger(r.amount)||r.amount<=0||!Number.isSafeInteger(r.usd)||r.usd<0||!Number.isInteger(r.cycle)||r.cycle<1||r.cycle>db.state.funds.length)throw Error('Invalid amount or historical cash cycle. Import its cash receipts first.');
  const raw={...r,amount:(r.amount/100).toFixed(2),reviewed:true,photo:'',voiceNote:'',hash:''};
  if(current){
   if(current.cycle!==r.cycle)throw Error('Imported correction cannot change the historical cash cycle.');
   Ledger.edit(db.state,current.id,raw);const updated=db.state.vouchers.find(x=>x.id===current.id);if(updated.amount!==r.amount||updated.usd!==r.usd)throw Error('Transferred currency conversion is inconsistent.');
   validateVoucher(updated);updated.updatedBy=u.name;updated.updatedAt=new Date().toISOString();
  }else{
   Ledger.add(db.state,raw);const added=db.state.vouchers[db.state.vouchers.length-1];added.cycle=r.cycle;added.depot=r.depot;
   if(added.amount!==r.amount||added.usd!==r.usd)throw Error('Transferred currency conversion is inconsistent.');validateVoucher(added);
   added.createdBy=u.name;added.createdAt=new Date().toISOString();
  }
 }else if(kind==='fund'){
  if(u.role!=='admin')throw Error('Only Admin can import cash receipts.');
  if(!Number.isSafeInteger(r.amount)||r.amount<=0)throw Error('Invalid cash receipt.');
  if(rows.some(x=>x.date===r.date&&x.amount===r.amount&&x.reference===r.reference))throw Error('Possible duplicate cash receipt with a different ID. Admin must reconcile.');
  if(q.record.id!==db.state.funds.length+1)throw Error('Cash receipt sequence differs. Refresh or import earlier receipts first.');
  Ledger.fund(db.state,{date:r.date,amount:(r.amount/100).toFixed(2),reference:r.reference});db.state.funds[db.state.funds.length-1].uid=r.uid;
 }else{
  if(u.role!=='admin')throw Error('Only Admin can import exchange rates.');Ledger.setRate(db.state,r.date,r.rate);
 }
 db.transferReceipts[q.operationId]=payload;return true;
}
