VERSION 9 UPDATE: read UPDATE_V9.txt first.

PRIMEWAY & LOLLYBIRD ANDROID V8 — LOCAL SAVING / MANUAL SYNCHRONIZATION

KEEP YOUR EXISTING GOOGLE DATABASE
1. In the existing app, export Excel and Backup ZIP. Keep both outside the app.
2. In Google Drive, download a copy of database.json from the existing shared petty cash folder. Do not edit or replace it. This is a precautionary backup.
3. In the SAME Apps Script project, replace ALL Code.gs text with PrimeWay_Google_Database_Code.txt (also included at cloud/Code.gs). Paste once. Do not add Ledger.gs/Server.js/agents separately; the complete file includes them.
4. Save. Do NOT run setupPrimeWay. Existing DATABASE_ID, FOLDER_ID, users, Azure properties and vouchers stay unchanged. V8 adds synchronization receipts to the existing JSON only when accepting changes.
5. If permissions are requested, run authorizeExternalAccess and approve Drive / external-service access under the project owner's account. Use Incognito with only the owner's Google account if the authorization link fails.
6. Deploy > Manage deployments > existing ACTIVE web app > pencil > New version > Deploy. Execute as Me (owner); access Anyone. Keep the same /exec address and personal access codes.

BUILD / INSTALL ANDROID V8
7. Upload PrimeWay_Lollybird_Petty_Cash_Android_V8.zip to the GitHub repository. In .github/workflows/build-apk.yml, change only Android_V7.zip to Android_V8.zip. Keep the existing signing-key cache unchanged. A complete workflow is included as build-apk.yml; use it only if your existing workflow is missing.
8. Actions > Build Android APK > Run workflow > main. On success open run Summary > Artifacts > PrimeWay-Android-APK. Extract the downloaded ZIP and install app-debug.apk over the existing app.
9. Do not uninstall if Android reports a package conflict. An update needs the original signing key. Preserve local data and resolve signing before installation. This package is source code; it is not an already compiled APK.
10. Connect once on each device to download the existing shared ledger. Same device / existing signed-in user can reopen offline after this first successful V8 connection.

DAILY USE
11. Save reviewed voucher stores it durably on this device, with its photo/voice note, even without internet. It is not yet saved on Google.
12. Settings > Synchronize now: downloads the latest ledger, sends pending vouchers/corrections separately, then downloads the combined ledger. Refresh shared database downloads only; it does not upload pending changes.
13. Pending entries remain if the network, permissions, Google server or Azure fails. Repeating synchronization uses the same operation ID so an already accepted voucher is not charged twice.
14. Pending changes are bound to their database URL and user. Do not change user or database while this replica has pending work. Sign out preserves the replica but disables new entries until signing in again.
15. Ledger edits of synchronized vouchers are queued locally. A pending NEW voucher must synchronize before editing. One correction at a time per voucher. Conflicting corrections remain pending for explicit review; an administrator/editor compares the shared record and re-enters the correction against the current version. Export backup before dismissing any pending item.
16. Duplicate PCV/photo entries are rejected by the server and retained locally for review. Cash-cycle changes while offline are flagged rather than silently moving expenses to another replenishment period.
17. Balance is last shared download plus this device's pending changes. It cannot include other users' unuploaded entries. Reports are provisional; ask ALL users to sync before preparing management approval.
18. Cash replenishment, exchange-rate/master changes and user administration remain ONLINE operations. Synchronize this device's pending vouchers before changing cash/master settings. Offline vouchers retain their entered exchange rate.
19. Offline photos can be saved with manually entered details. Azure handwriting extraction requires internet. Voice note recording works offline; speech-to-text availability depends on Android's installed speech service/languages.
20. Keep regular Backup ZIP exports. The backup now includes sync.json (acknowledged ledger and pending queue) plus local media. Excel is for reporting, not synchronization. No automatic backup import/merge was added.

VALIDATION BEFORE ALL STAFF UPDATE
- Logic tests cover monetary conversion, persistence/restart, preserving shared records, concurrent adds, retry after lost acknowledgement, duplicate protection, conflict handling, permissions and disk failure.
- Android APK compilation and live Google/Azure/device integration are not verified in this environment. Build with GitHub and test on two devices first.
- Test airplane mode: save a unique test PCV, close/reopen, verify pending entry. Reconnect and synchronize twice; confirm only one shared entry and one expense deduction on the second device.
- Keep the opening funds and previous vouchers unchanged. Do not reset the database or re-run setup.
