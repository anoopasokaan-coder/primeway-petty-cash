package com.primeway.pettycash;
import android.content.Context;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.net.*;

final class SharedCloud {
 private final Context context;
 private final CredentialStore credentials;
 static final String DEFAULT_ENDPOINT="https://script.google.com/macros/s/AKfycbzFBZ13BSqj0d2ntSJcn6FM2BL_0wu-k8F1oRz6BBdhCU5g7Npx8mdKz8wYGUb_GvLs/exec";
 private volatile String endpoint="",token="";
 SharedCloud(Context c){context=c;credentials=new CredentialStore(c);endpoint=c.getSharedPreferences("shared",0).getString("endpoint",DEFAULT_ENDPOINT);token=credentials.load(endpoint);}
 boolean signedIn(){return !token.isEmpty();}
 JSONObject analyze(File photo)throws Exception{
  JSONObject q=new JSONObject();q.put("action","ocr.start");try(InputStream in=new FileInputStream(photo)){q.put("image",Base64.encodeToString(read(in,4000000),Base64.NO_WRAP));}
  JSONObject r=request(q);if(!r.optBoolean("ok"))throw new IOException(r.optString("error"));String job=r.getString("job");
  long deadline=System.currentTimeMillis()+120000;
  while(System.currentTimeMillis()<deadline){Thread.sleep(1800);q=new JSONObject();q.put("action","ocr.poll");q.put("job",job);r=request(q);if(!r.optBoolean("ok"))throw new IOException(r.optString("error"));if(r.has("analysis"))return r.getJSONObject("analysis");}
  throw new IOException("Azure reading timed out. Check before retrying.");
 }
 String endpoint(){return endpoint;}
 String configure(String url,String code)throws Exception{
  URI uri=new URI(url.trim());if(!"https".equals(uri.getScheme())||!"script.google.com".equals(uri.getHost())||!uri.getPath().matches("/macros/s/[A-Za-z0-9_-]+/exec")||uri.getQuery()!=null)throw new IOException("Use the Google Apps Script deployment URL ending /exec.");
  if(!code.trim().matches("[A-Fa-f0-9]{64}"))throw new IOException("Enter your personal 64-character access code.");
  credentials.clear();endpoint=url.trim();token=code.trim();context.getSharedPreferences("shared",0).edit().putString("endpoint",endpoint).apply();return "OK";
 }
 void signOut(){token="";credentials.clear();}
 JSONObject request(JSONObject q)throws Exception{
  if(token.isEmpty())throw new IOException("Sign in to shared cash before saving.");q.put("token",token);
  if("save".equals(q.optString("action"))){
   JSONArray vouchers=q.getJSONObject("state").getJSONArray("vouchers");JSONObject media=new JSONObject();
   for(int i=0;i<vouchers.length();i++){JSONObject v=vouchers.getJSONObject(i);if(!v.has("createdBy")){
    attach(media,"photo",new File(context.getFilesDir()+"/photos/",safe(v.optString("photo"))));
    attach(media,"note",new File(context.getFilesDir()+"/notes/",safe(v.optString("voiceNote"))));
   }}q.put("attachments",media);
  }
  byte[] data=q.toString().getBytes("UTF-8");if(data.length>16000000)throw new IOException("Request too large. Use a smaller photo or shorter note.");
  HttpURLConnection conn=(HttpURLConnection)new URL(endpoint).openConnection();conn.setConnectTimeout(20000);conn.setReadTimeout(90000);conn.setRequestMethod("POST");conn.setDoOutput(true);conn.setRequestProperty("Content-Type","application/json; charset=UTF-8");conn.setInstanceFollowRedirects(false);
  try{
   try(OutputStream out=conn.getOutputStream()){out.write(data);}
   int status=conn.getResponseCode();String location=conn.getHeaderField("Location");
   if(status==301||status==302||status==303){conn.disconnect();URI redirect=new URI(location);if(!"https".equals(redirect.getScheme())||!"script.googleusercontent.com".equals(redirect.getHost()))throw new IOException("Unexpected service redirect.");
    conn=(HttpURLConnection)new URL(location).openConnection();conn.setConnectTimeout(20000);conn.setReadTimeout(90000);status=conn.getResponseCode();}
   if(status!=200)throw new IOException("Shared service returned HTTP "+status);
   JSONObject result;try(InputStream in=conn.getInputStream()){result=new JSONObject(new String(read(in,20000000),"UTF-8"));}
   if("attachment".equals(q.optString("action"))&&result.optBoolean("ok")){
    String name=safe(q.getString("name")),kind=q.optString("kind");if(name.isEmpty()||!("photo".equals(kind)||"note".equals(kind)))throw new IOException("Invalid attachment.");
    File dir=new File(context.getFilesDir(),"photo".equals(kind)?"photos":"notes");dir.mkdirs();File target=new File(dir,name);
    byte[] bytes=Base64.decode(result.getString("data"),Base64.DEFAULT);try(FileOutputStream out=new FileOutputStream(target)){out.write(bytes);}result.remove("data");result.put("name",name);
   }
   if(result.optBoolean("ok")&&"load".equals(q.optString("action")))credentials.save(token,endpoint);
   return result;
  }finally{conn.disconnect();}
 }
 private String safe(String name)throws IOException{if(!name.isEmpty()&&!name.matches("[A-Za-z0-9_.-]+"))throw new IOException("Invalid attachment name.");return name;}
 private void attach(JSONObject o,String key,File file)throws Exception{if(file.isFile())try(InputStream in=new FileInputStream(file)){o.put(key,Base64.encodeToString(read(in,8000000),Base64.NO_WRAP));}}
 private byte[] read(InputStream in,int max)throws IOException{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new IOException("Attachment/response too large.");out.write(buf,0,n);}return out.toByteArray();}
}
