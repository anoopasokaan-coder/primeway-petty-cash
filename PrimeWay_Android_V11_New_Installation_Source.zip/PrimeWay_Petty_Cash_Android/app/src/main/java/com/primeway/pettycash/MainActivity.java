package com.primeway.pettycash;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.print.PrintManager;
import android.util.AtomicFile;
import android.webkit.*;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.JSONObject;
import java.io.*;
import java.security.MessageDigest;
import java.util.zip.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Color;
import androidx.exifinterface.media.ExifInterface;

public class MainActivity extends Activity {
    private WebView web;
    private SharedCloud shared;
    private File pending;
    private volatile boolean recognizing=false;
    private final int CAMERA=101,GALLERY=102,TRANSFER=105,EXPORT_DATABASE=106;
    private File databaseExport;
    private AtomicFile stateFile;
    private TextRecognizer recognizer;
    private boolean online=false;
    private android.media.MediaRecorder recorder;
    private File noteFile;
    private String noteField="paid_to";
    private final android.os.Handler noteHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable noteLimit=()->stopNoteRecording();
    private String azureEndpoint="",azureKey="",voiceField="";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        shared=new SharedCloud(this);
        stateFile=new AtomicFile(new File(getFilesDir(),"ledger.json"));
        recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        if(b!=null && b.containsKey("pending")) pending=new File(getFilesDir()+"/photos/",b.getString("pending"));
        web=new WebView(this);setContentView(web);
        web.setPadding(0,0,0,0);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setDomStorageEnabled(false);
        web.addJavascriptInterface(new Bridge(),"Native");
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest request){return true;}
            @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
                String path=r.getUrl().getPath();
                if(!"app.local".equals(r.getUrl().getHost()))return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
                try {
                    if(path.startsWith("/photos/")){
                        String name=path.substring(8);
                        if(!name.matches("[A-Za-z0-9_.-]+"))throw new IOException("Invalid path");
                        return new WebResourceResponse("image/jpeg",null,new FileInputStream(new File(getFilesDir()+"/photos/",name)));
                    }
                    String name=path.substring(1);
                    if(!name.matches("[A-Za-z0-9_.-]+"))throw new IOException("Invalid path");
                    return new WebResourceResponse(name.endsWith(".js")?"application/javascript":"text/html","UTF-8",getAssets().open(name));
                }catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));}
            }
        });
        web.loadUrl("https://app.local/index.html");
    }
    @Override public void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);if(pending!=null)b.putString("pending",pending.getName());}
    private void event(String name,JSONObject value){runOnUiThread(()->web.evaluateJavascript("window."+name+"("+value.toString()+")",null));}
    private JSONObject object(String... pairs){JSONObject o=new JSONObject();try{for(int i=0;i<pairs.length;i+=2)o.put(pairs[i],pairs[i+1]);}catch(Exception ignored){}return o;}
    private void error(String msg){event("onPhoto",object("error",msg));}
    private void pick(boolean camera){
        if(recognizing||recorder!=null){Toast.makeText(this,"Wait for photo extraction",Toast.LENGTH_SHORT).show();return;}
        try{
            if(camera){
                File dir=new File(getFilesDir(),"photos");dir.mkdirs();pending=File.createTempFile("voucher_",".jpg",dir);
                Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",pending);
                Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);intent.putExtra(MediaStore.EXTRA_OUTPUT,uri);
                intent.setClipData(ClipData.newRawUri("voucher",uri));intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(intent,CAMERA);
            }else{
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.setType("image/*");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,GALLERY);
            }
        }catch(Exception e){error("Unable to open camera or gallery: "+e.getMessage());}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==EXPORT_DATABASE){
            if(result!=RESULT_OK||data==null||data.getData()==null)return;
            File source=databaseExport;if(source==null){Toast.makeText(this,"Export interrupted. Please export again.",Toast.LENGTH_LONG).show();return;}
            Uri target=data.getData();new Thread(()->{try(InputStream in=new FileInputStream(source);OutputStream out=getContentResolver().openOutputStream(target)){
                if(out==null)throw new IOException("Cannot open the selected destination");copy(in,out);runOnUiThread(()->Toast.makeText(this,"Database export saved",Toast.LENGTH_LONG).show());
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();return;
        }
        if(request==TRANSFER){
            if(result!=RESULT_OK||data==null||data.getData()==null)return;
            Uri uri=data.getData();new Thread(()->{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>32000000)throw new IOException("Transfer file exceeds 32 MB");out.write(buffer,0,n);}new JSONObject(out.toString("UTF-8"));event("onTransferFile",object("data",out.toString("UTF-8")));
            }catch(Exception e){event("onTransferFile",object("error",e.getMessage()));}}).start();return;
        }
        if(request==103){
            if(result==RESULT_OK && data!=null){java.util.ArrayList<String> words=data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);if(words!=null&&!words.isEmpty()){JSONObject value=object("field",voiceField,"text",words.get(0));try{value.put("alternatives",new org.json.JSONArray(words));}catch(Exception ignored){}event("onVoice",value);}else event("onVoice",object("error","No speech recognized. Try again."));}
            else event("onVoice",object("error","Voice input cancelled."));return;
        }
        if(request!=CAMERA && request!=GALLERY)return;
        if(result!=RESULT_OK){error("Photo selection cancelled.");return;}
        try{
            if(request==GALLERY){
                File dir=new File(getFilesDir(),"photos");dir.mkdirs();pending=File.createTempFile("voucher_",".jpg",dir);
                if(data==null || data.getData()==null)throw new IOException("No image selected");
                try(InputStream in=getContentResolver().openInputStream(data.getData());OutputStream out=new FileOutputStream(pending)){copy(in,out);}
            }
            if(pending==null || pending.length()==0)throw new IOException("Camera did not save the photo");
            File imageFile=pending;normalizePhoto(imageFile);String hash=hash(imageFile);recognizing=true;
            android.net.ConnectivityManager cm=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            android.net.NetworkInfo network=cm.getActiveNetworkInfo();
            boolean connected=network!=null&&network.isConnected();
            if(!connected){recognizer.process(InputImage.fromFilePath(this,Uri.fromFile(imageFile)))
                .addOnSuccessListener(text->recognizeRegions(imageFile,hash,text.getText()))
                .addOnFailureListener(e->{recognizing=false;event("onPhoto",object("photo",imageFile.getName(),"hash",hash,"error","Photo kept locally. Device reading failed; enter details manually. Azure handwriting needs internet."));});return;}
            if(shared.signedIn()||online){
                String endpoint=azureEndpoint,key=azureKey;
                new Thread(()->{try{JSONObject read=shared.signedIn()?shared.analyze(imageFile):OnlineReader.analyze(imageFile,endpoint,key);JSONObject resultJson=object("photo",imageFile.getName(),"hash",hash,"online","true");resultJson.put("analysis",read);recognizing=false;event("onPhoto",resultJson);}catch(Exception e){recognizing=false;event("onPhoto",object("photo",imageFile.getName(),"hash",hash,"error",e.getMessage()));}}).start();return;
            }
            recognizer.process(InputImage.fromFilePath(this,Uri.fromFile(imageFile)))
                .addOnSuccessListener(text->recognizeRegions(imageFile,hash,text.getText()))
                .addOnFailureListener(e->{recognizing=false;event("onPhoto",object("error","Text extraction failed; enter fields manually.","photo",imageFile.getName(),"hash",hash));});
        }catch(Exception e){recognizing=false;error(e.getMessage());}
    }
    private void normalizePhoto(File file)throws Exception {
        BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getPath(),o);o.inSampleSize=1;while(Math.max(o.outWidth,o.outHeight)/o.inSampleSize>2400)o.inSampleSize*=2;o.inJustDecodeBounds=false;
        Bitmap image=BitmapFactory.decodeFile(file.getPath(),o);if(image==null)throw new IOException("Cannot open this image. Choose JPEG or PNG.");
        ExifInterface exif=new ExifInterface(file);Matrix m=new Matrix();m.postRotate(exif.getRotationDegrees());if(exif.isFlipped())m.postScale(-1,1);
        Bitmap normalized=Bitmap.createBitmap(image,0,0,image.getWidth(),image.getHeight(),m,true);
        File temp=new File(file.getParentFile(),file.getName()+".tmp");try(OutputStream out=new FileOutputStream(temp)){if(!normalized.compress(Bitmap.CompressFormat.JPEG,94,out))throw new IOException("Photo could not be saved.");}
        if(!temp.renameTo(file)){temp.delete();throw new IOException("Photo normalization failed.");}if(normalized!=image)image.recycle();normalized.recycle();
    }
    private void recognizeRegions(File file,String hash,String full){
        try{
            BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getPath(),options);
            options.inSampleSize=Math.max(1,Math.max(options.outWidth,options.outHeight)/2400);options.inJustDecodeBounds=false;
            Bitmap bitmap=BitmapFactory.decodeFile(file.getPath(),options);if(bitmap==null)throw new IOException("Cannot decode photo");
            ExifInterface exif=new ExifInterface(file);int orientation=exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);
            Matrix rotation=new Matrix();if(orientation==ExifInterface.ORIENTATION_ROTATE_90)rotation.postRotate(90);if(orientation==ExifInterface.ORIENTATION_ROTATE_180)rotation.postRotate(180);if(orientation==ExifInterface.ORIENTATION_ROTATE_270)rotation.postRotate(270);
            bitmap=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),rotation,true);
            String[] names={"number","date","paid_to","words","particulars","amount"};
            double[][] boxes={{.775,.245,.925,.345},{.09,.265,.30,.365},{.12,.38,.95,.455},{.16,.465,.96,.55},{.155,.555,.96,.64},{.035,.745,.27,.845}};
            java.util.List<com.google.android.gms.tasks.Task<com.google.mlkit.vision.text.Text>> tasks=new java.util.ArrayList<>();
            for(int i=0;i<names.length;i++){
                double[] b=boxes[i];int x=(int)(b[0]*bitmap.getWidth()),y=(int)(b[1]*bitmap.getHeight());
                Bitmap crop=Bitmap.createBitmap(bitmap,x,y,(int)((b[2]-b[0])*bitmap.getWidth()),(int)((b[3]-b[1])*bitmap.getHeight()));
                crop=enhanceInk(crop,i==0);crop=Bitmap.createScaledBitmap(crop,crop.getWidth()*2,crop.getHeight()*2,true);
                tasks.add(recognizer.process(InputImage.fromBitmap(crop,0)));
            }
            com.google.android.gms.tasks.Tasks.whenAllComplete(tasks).addOnCompleteListener(done->{
                JSONObject regions=new JSONObject();for(int i=0;i<tasks.size();i++)try{if(tasks.get(i).isSuccessful())regions.put(names[i],tasks.get(i).getResult().getText());}catch(Exception ignored){}
                JSONObject result=object("text",full,"photo",file.getName(),"hash",hash);try{result.put("regions",regions);}catch(Exception ignored){}
                recognizing=false;event("onPhoto",result);
            });
        }catch(Exception e){recognizing=false;event("onPhoto",object("text",full,"photo",file.getName(),"hash",hash,"error","Field enhancement unavailable. Review the full photo."));}
    }
    private Bitmap enhanceInk(Bitmap input,boolean serial){
        int[] pixels=new int[input.getWidth()*input.getHeight()];input.getPixels(pixels,0,input.getWidth(),0,0,input.getWidth(),input.getHeight());
        int[] hist=new int[256];for(int p:pixels)hist[serial?Color.green(p):Color.red(p)]++;
        int low=0,high=255,count=0;for(int i=0;i<256;i++){count+=hist[i];if(count>pixels.length/100){low=i;break;}}
        count=0;for(int i=255;i>=0;i--){count+=hist[i];if(count>pixels.length/100){high=i;break;}}
        for(int i=0;i<pixels.length;i++){int v=serial?Color.green(pixels[i]):Color.red(pixels[i]);v=Math.max(0,Math.min(255,(v-low)*255/Math.max(1,high-low)));pixels[i]=Color.rgb(v,v,v);}
        return Bitmap.createBitmap(pixels,input.getWidth(),input.getHeight(),Bitmap.Config.ARGB_8888);
    }
    private static void copy(InputStream in,OutputStream out)throws IOException{if(in==null)throw new IOException("Cannot read file");byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
    private static String hash(File file)throws Exception{MessageDigest md=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(file)){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)md.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte b:md.digest())s.append(String.format("%02x",b&255));return s.toString();}
    private void shareFile(File file,String mime){
        Uri uri=FileProvider.getUriForFile(this,getPackageName()+".files",file);
        Intent intent=new Intent(Intent.ACTION_SEND);intent.setType(mime);intent.putExtra(Intent.EXTRA_STREAM,uri);
        intent.setClipData(ClipData.newRawUri("Petty cash",uri));intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent,"Share petty cash file"));
    }
    private void startNoteRecording(String field){
        if(recorder!=null||recognizing){event("onVoice",object("error","Finish the current recording / reading first."));return;}
        noteField=field;
        if(android.os.Build.VERSION.SDK_INT>=23&&checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},204);return;}
        try{
            File folder=new File(getFilesDir(),"notes");folder.mkdirs();noteFile=File.createTempFile("voice_",".m4a",folder);
            recorder=new android.media.MediaRecorder();recorder.setAudioSource(android.media.MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4);recorder.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC);recorder.setOutputFile(noteFile.getPath());recorder.prepare();recorder.start();
            event("onNoteState",object("state","recording","message","Recording voice note — tap Stop. Maximum 60 seconds."));noteHandler.postDelayed(noteLimit,60000);
        }catch(Exception e){if(recorder!=null){recorder.release();recorder=null;}event("onNoteState",object("state","idle","message",e.getMessage()));}
    }
    private void stopNoteRecording(){
        if(recorder==null)return;noteHandler.removeCallbacks(noteLimit);
        try{recorder.stop();}catch(Exception e){recorder.release();recorder=null;if(noteFile!=null)noteFile.delete();event("onNoteState",object("state","idle","message","Recording too short. Try again."));return;}
        recorder.release();recorder=null;File file=noteFile;String field=noteField;
        event("onNoteState",object("state","idle","file",file.getName(),"message","Voice note saved. You can share it."));
        event("onVoice",object("error","Voice note saved. Use Speak field to convert speech into text with your Android speech service.","note",file.getName()));
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==204){if(results.length>0&&results[0]==android.content.pm.PackageManager.PERMISSION_GRANTED)startNoteRecording(noteField);else event("onNoteState",object("state","idle","message","Microphone permission denied. Enable it in Android Settings > Apps."));}}
    @Override protected void onPause(){if(recorder!=null)stopNoteRecording();super.onPause();}
    class Bridge {
        @JavascriptInterface public synchronized String loadSync(){
            android.util.AtomicFile f=new android.util.AtomicFile(new File(getFilesDir(),"sync.json"));
            if(!f.getBaseFile().exists())return "";
            try(InputStream in=f.openRead();ByteArrayOutputStream out=new ByteArrayOutputStream()){copy(in,out);return out.toString("UTF-8");}catch(Exception e){return "READ_ERROR";}
        }
        @JavascriptInterface public synchronized String saveSync(String json){
            android.util.AtomicFile f=new android.util.AtomicFile(new File(getFilesDir(),"sync.json"));FileOutputStream out=null;
            try{new JSONObject(json);out=f.startWrite();out.write(json.getBytes("UTF-8"));f.finishWrite(out);return "OK";}catch(Exception e){if(out!=null)f.failWrite(out);return "Local sync save failed: "+e.getMessage();}
        }
        @JavascriptInterface public boolean sharedSignedIn(){return shared.signedIn();}
        @JavascriptInterface public String sharedEndpoint(){return shared.endpoint();}
        @JavascriptInterface public String sharedConfigure(String url,String code){try{return shared.configure(url,code);}catch(Exception e){return e.getMessage();}}
        @JavascriptInterface public void sharedSignOut(){shared.signOut();}
        @JavascriptInterface public void sharedRequest(String request,String id){new Thread(()->{
            JSONObject result;try{result=shared.request(new JSONObject(request));}catch(Exception e){result=object("error","Shared request failed. Refresh to check whether it was saved before retrying. "+e.getMessage());}
            try{result.put("requestId",id);}catch(Exception ignored){}event("onShared",result);
        }).start();}

        @JavascriptInterface public void recordNote(String field){runOnUiThread(()->startNoteRecording(field));}
        @JavascriptInterface public void stopNote(){runOnUiThread(()->stopNoteRecording());}
        @JavascriptInterface public void shareNote(String name){runOnUiThread(()->{try{if(!name.matches("voice_[A-Za-z0-9_.-]+\\.m4a"))throw new IOException("Invalid note");shareFile(new File(getFilesDir()+"/notes/",name),"audio/mp4");}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}});}

        @JavascriptInterface public String configureOnline(String endpoint,String key,boolean enabled){
            try{if(enabled){endpoint=OnlineReader.endpoint(endpoint);if(key.trim().isEmpty())throw new IOException("Enter your API key.");}if(recognizing)throw new IOException("Wait for reading to finish.");azureEndpoint=endpoint;azureKey=key;online=enabled;return "OK";}catch(Exception e){return e.getMessage();}
        }
        @JavascriptInterface public void voice(String field,String language,boolean offline){runOnUiThread(()->{
            if(recognizing||recorder!=null){event("onVoice",object("error","Wait for photo reading to finish."));return;}
            try{voiceField=field;Intent i=new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE,language);i.putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE,offline);i.putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS,5);i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT,"Speak voucher field: "+field);startActivityForResult(i,103);}catch(Exception e){event("onVoice",object("error","Install/enable a speech recognition service, or use your keyboard microphone."));}
        });}
        @JavascriptInterface public synchronized String load(){
            if(!stateFile.getBaseFile().exists())return "";
            try(InputStream in=stateFile.openRead();ByteArrayOutputStream out=new ByteArrayOutputStream()){copy(in,out);return out.toString("UTF-8");}
            catch(Exception e){return "READ_ERROR";}
        }
        @JavascriptInterface public synchronized String save(String json){
            FileOutputStream out=null;
            try{JSONObject obj=new JSONObject(json);if(obj.getInt("version")!=1)throw new IOException("Unknown ledger format");out=stateFile.startWrite();out.write(json.getBytes("UTF-8"));stateFile.finishWrite(out);return "OK";}
            catch(Exception e){if(out!=null)stateFile.failWrite(out);return "Save failed: "+e.getMessage();}
        }
        @JavascriptInterface public void camera(){runOnUiThread(()->pick(true));}
        @JavascriptInterface public void gallery(){runOnUiThread(()->pick(false));}
        @JavascriptInterface public void warning(String message){runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setTitle("Petty cash warning").setMessage(message).setPositiveButton("OK",null).show());}
        @JavascriptInterface public String archive(String content,int cycle){
            try{File dir=new File(getFilesDir(),"reports");dir.mkdirs();File f=new File(dir,"Cycle_"+cycle+"_"+System.currentTimeMillis()+".html");try(OutputStream o=new FileOutputStream(f)){o.write(content.getBytes("UTF-8"));}return "OK";}
            catch(Exception e){return e.getMessage();}
        }
        @JavascriptInterface public void printReport(String content){runOnUiThread(()->{
            WebView report=new WebView(MainActivity.this);
            report.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String url){
                PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                pm.print("PrimeWay Lollybird Petty Cash",v.createPrintDocumentAdapter("Petty cash summary"),null);
            }});report.loadDataWithBaseURL(null,content,"text/html","UTF-8",null);
        });}
        @JavascriptInterface public void share(String content,String kind){runOnUiThread(()->{
            try{File dir=new File(getCacheDir(),"exports");dir.mkdirs();if("xlsx".equals(kind)){org.json.JSONArray input=new org.json.JSONArray(content);String[][] rows=new String[input.length()][];for(int i=0;i<input.length();i++){org.json.JSONArray row=input.getJSONArray(i);rows[i]=new String[row.length()];for(int j=0;j<row.length();j++)rows[i][j]=row.optString(j,"");}File workbook=new File(dir,"PrimeWay_Lollybird_Petty_Cash.xlsx");XlsxExporter.write(workbook,rows);shareFile(workbook,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");return;}boolean csv="csv".equals(kind);File f=new File(dir,csv?"Petty_Cash.csv":"Petty_Cash_Report.html");try(OutputStream out=new FileOutputStream(f)){out.write(content.getBytes("UTF-8"));}shareFile(f,csv?"text/csv":"text/html");}
            catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}
        });}
        @JavascriptInterface public void pickTransfer(){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,TRANSFER);}catch(Exception e){event("onTransferFile",object("error",e.getMessage()));}});}
        @JavascriptInterface public void exportTransfer(String json){runOnUiThread(()->{try{if(json.length()>32000000)throw new IOException("Transfer file too large");new JSONObject(json);File dir=new File(getCacheDir(),"exports");dir.mkdirs();File f=new File(dir,"PrimeWay_Database_V9_"+System.currentTimeMillis()+".json");try(OutputStream out=new FileOutputStream(f)){out.write(json.getBytes("UTF-8"));}new AlertDialog.Builder(MainActivity.this).setTitle("Database export ready").setMessage("Save this JSON file or send it to another person for import and merge.").setPositiveButton("Save to Files",(d,w)->{try{databaseExport=f;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,f.getName());startActivityForResult(i,EXPORT_DATABASE);}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}}).setNegativeButton("Share",(d,w)->shareFile(f,"application/json")).setNeutralButton("Cancel",null).show();}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}});}
        @JavascriptInterface public synchronized String transferRecovery(String json){
            try{new JSONObject(json);File dir=new File(getFilesDir(),"import_recovery");dir.mkdirs();File f=new File(dir,"before_import_"+System.currentTimeMillis()+".json");try(OutputStream out=new FileOutputStream(f)){out.write(json.getBytes("UTF-8"));}return "OK";}catch(Exception e){return "Recovery backup failed: "+e.getMessage();}
        }
        @JavascriptInterface public String transferPhoto(String name){
            try{if(!name.matches("[A-Za-z0-9_.-]+"))throw new IOException("Invalid photo name");File f=new File(getFilesDir()+"/photos/",name);if(f.length()>8000000)throw new IOException("Photo too large");try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){copy(in,out);return android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP);}}catch(Exception e){return "ERROR: "+e.getMessage();}
        }
        @JavascriptInterface public String saveTransferPhoto(String encoded){
            try{if(encoded.length()>11000000)throw new IOException("Imported photo too large");byte[] bytes=android.util.Base64.decode(encoded,android.util.Base64.DEFAULT);if(bytes.length>8000000||bytes.length<3||(bytes[0]&255)!=255||(bytes[1]&255)!=216)throw new IOException("Imported photo must be JPEG under 8 MB");File dir=new File(getFilesDir(),"photos");dir.mkdirs();File f=File.createTempFile("import_",".jpg",dir);try(OutputStream out=new FileOutputStream(f)){out.write(bytes);}return f.getName();}catch(Exception e){return "ERROR: "+e.getMessage();}
        }
        @JavascriptInterface public void backup(){runOnUiThread(()->{
            try{
                File dir=new File(getCacheDir(),"exports");dir.mkdirs();File file=new File(dir,"PettyCash_Backup.zip");
                new AlertDialog.Builder(MainActivity.this).setTitle("Full recovery backup").setMessage("Include local voucher photos and voice notes? Database transfers are a separate option.").setPositiveButton("Database only",(d,w)->writeRecoveryZip(false)).setNegativeButton("Include copies",(d,w)->writeRecoveryZip(true)).show();
            }catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}
        });}
    }
    private void writeRecoveryZip(boolean media){try{File dir=new File(getCacheDir(),"exports");dir.mkdirs();File f=new File(dir,"PettyCash_Recovery.zip");try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(f))){zipRecovery(getFilesDir(),getFilesDir(),z,media);}shareFile(f,"application/zip");}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void zipRecovery(File base,File folder,ZipOutputStream out,boolean media)throws IOException{File[] files=folder.listFiles();if(files==null)return;for(File f:files){if(f.isDirectory()){if(media||(!f.getName().equals("photos")&&!f.getName().equals("notes")))zipRecovery(base,f,out,media);}else{out.putNextEntry(new ZipEntry(base.toURI().relativize(f.toURI()).getPath()));try(InputStream in=new FileInputStream(f)){copy(in,out);}out.closeEntry();}}}
    private void zip(File base,File folder,ZipOutputStream out)throws IOException{
        File[] files=folder.listFiles();if(files==null)return;
        for(File f:files){if(f.isDirectory())zip(base,f,out);else{String name=base.toURI().relativize(f.toURI()).getPath();out.putNextEntry(new ZipEntry(name));try(InputStream in=new FileInputStream(f)){copy(in,out);}out.closeEntry();}}
    }
    @Override protected void onDestroy(){recognizer.close();super.onDestroy();}
}
