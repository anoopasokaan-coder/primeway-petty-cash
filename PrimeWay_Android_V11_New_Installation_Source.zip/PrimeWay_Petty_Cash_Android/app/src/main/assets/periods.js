'use strict';
(function(g){
const copy=x=>JSON.parse(JSON.stringify(x));
function ledgerBalance(s){return s.funds.reduce((a,r)=>a+r.amount,0)-s.vouchers.reduce((a,r)=>a+r.usd,0);}
function open(s,reporting){
 const reports=reporting?.reports||[],last=reports[reports.length-1];
 const used=new Set(reports.flatMap(r=>r.vouchers.map(v=>v.uid)));
 const vouchers=s.vouchers.filter(v=>!used.has(v.uid)).map(copy);
 const fundIds=new Set(reports.flatMap(r=>r.funds.map(f=>f.uid)));
 const funds=s.funds.filter(f=>!fundIds.has(f.uid)).map(copy);
 const opening=last?last.closing:0,expenses=vouchers.reduce((a,v)=>a+v.usd,0),received=funds.reduce((a,f)=>a+f.amount,0);
 const closing=ledgerBalance(s),adjustments=closing-(opening+received-expenses);
 return {number:reports.length+1,start:last?.submittedAt||null,vouchers,funds,opening,expenses,received,adjustments,closing};
}
function html(r,provisional=false){
 const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const money=x=>(x/100).toFixed(2);
 return '<!doctype html><html><head><meta charset="utf-8"><title>PrimeWay Replenishment '+r.number+'</title><style>body{font:13px Arial;margin:24px;color:#102c48}h1{border-bottom:4px solid #087f69}table{width:100%;border-collapse:collapse}td,th{border:1px solid #ccc;padding:7px;text-align:left}th{background:#102c48;color:white}thead{display:table-header-group}tr{break-inside:avoid}@page{size:A4 landscape;margin:12mm}</style></head><body><h1>PrimeWay &amp; Lollybird — Replenishment report '+r.number+'</h1><p>'+ (provisional?'DRAFT — not submitted. Local pending entries may be included.':'SUBMITTED SNAPSHOT — '+esc(r.submittedAt)+' · '+esc(r.submittedBy))+'</p><p>Previous submission: '+esc(r.start||'Beginning of ledger')+' | End: '+esc(r.submittedAt||'Current draft')+'</p><p>Opening US$ '+money(r.opening)+' | Received '+money(r.received)+' | Expenses '+money(r.expenses)+' | Prior-period adjustments '+money(r.adjustments)+' | Closing '+money(r.closing)+'</p><p>Expense reimbursement requested: US$ '+money(r.expenses)+'. Cash receipts do not close reporting periods. Late uploads enter the next open report.</p><table><thead><tr>'+['PCV','Date','Payee','Depot','Particulars','Currency','Original amount','USD expense'].map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+r.vouchers.map(v=>'<tr>'+[v.number,v.date,v.paid_to,v.depot,v.particulars,v.currency,money(v.amount),money(v.usd)].map(x=>'<td>'+esc(x)+'</td>').join('')+'</tr>').join('')+'</tbody></table><p>Prepared: __________________ Checked: __________________ Approved: __________________</p></body></html>';
}
const api={open,html};if(typeof module!=='undefined'&&module.exports)module.exports=api;g.Periods=api;
})(typeof window!=='undefined'?window:globalThis);
