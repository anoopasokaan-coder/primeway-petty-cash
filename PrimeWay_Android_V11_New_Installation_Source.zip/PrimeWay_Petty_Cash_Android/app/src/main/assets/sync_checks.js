'use strict';
(function(g){
const numberKey=v=>{const s=String(v||'').replace(/\s/g,'').toUpperCase();return /^\d+$/.test(s)?s.replace(/^0+(?=\d)/,''):s;};
function comparable(v){const r={};for(const k of ['number','date','paid_to','agent','depot','particulars','words','currency','amount','rate','cycle'])r[k]=v[k]??'';r.number=numberKey(r.number);r.rate=r.currency==='USD'?'':String(Number(r.rate));return JSON.stringify(r);}
function analyze(op,state,L,T){
 try{
  if(!op||!op.operationId)throw Error('Permanent transaction ID is missing.');
  if(op.kind==='transfer'){
   T.validate(op.transferKind,op.record);
   if(op.transferKind!=='voucher')return {status:'ready'};
   const v=op.record,remote=state.vouchers.find(x=>x.uid===v.uid||numberKey(x.number)===numberKey(v.number));
   if(remote&&comparable(remote)===comparable(v))return {status:'already',remote};
   if(remote&&!op.base)return {status:'conflict',message:'PCV already exists with different details. Compare both copies.',remote};
   return {status:'ready'};
  }
  const raw=op.voucher;if(!raw||!raw.reviewed)throw Error('Review the voucher fields before synchronization.');
  for(const k of ['number','date','paid_to','particulars','words','currency','amount'])if(!String(raw[k]??'').trim())throw Error('Required field: '+k);
  for(const k of ['number','paid_to','particulars','words'])if(String(raw[k]).length>2000)throw Error('Voucher text too long: '+k);
  const temp=JSON.parse(JSON.stringify(state));temp.vouchers=[];L.add(temp,raw);const v=temp.vouchers[0];v.cycle=raw.cycle;
  if(!Number.isInteger(v.cycle)||v.cycle<1||v.cycle>state.funds.length)throw Error('Invalid historical cash receipt reference.');
  let spoken;try{spoken=g.InputHelpers.number(raw.words.replace(/\bonly\b/gi,''));}catch{}
  if(spoken!==undefined&&L.money(spoken)!==v.amount)throw Error('Amount in words differs from figures.');
  const remote=state.vouchers.find(x=>raw.uid&&x.uid===raw.uid||numberKey(x.number)===numberKey(raw.number));
  if(remote&&comparable(remote)===comparable(v))return {status:'already',remote};
  if(op.kind==='add'&&remote)return {status:'conflict',message:'PCV already exists with different details. Compare both copies.',remote};
  if(op.kind==='edit'){
   if(!remote)return {status:'conflict',message:'Shared voucher is missing. Pending correction retained.'};
   if(!op.base||comparable(remote)!==comparable(op.base))return {status:'conflict',message:'Shared voucher changed on another device. Compare before correcting.',remote};
  }
  return {status:'ready'};
 }catch(e){return {status:'invalid',message:'Needs correction: '+e.message};}
}
const api={numberKey,comparable,analyze};g.SyncChecks=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
