const fs=require('fs'),vm=require('vm'),a=require('assert/strict');const root='app/src/main/assets/';const html=fs.readFileSync(root+'index.html','utf8');
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);a.equal(ids.length,new Set(ids).size);
const nodes={};class Node{constructor(id){this.id=id;this.value='';this.textContent='';this.hidden=false;this.disabled=false;this.checked=false;this.dataset={};this.classList={toggle(){}};}addEventListener(){}querySelectorAll(){return [];}removeAttribute(){}get options(){return [...(this._html||'').matchAll(/<option(?: value="([^"]*)")?[^>]*>([^<]*)<\/option>/g)].map(m=>({value:m[1]??m[2]}));}set innerHTML(s){this._html=s;if(this.options.length&&!this.value)this.value=this.options[0].value;}get innerHTML(){return this._html||'';}reset(){for(const k of ['number','date','paid_to','agent','depot','particulars','words','currency','amount','rate'])nodes[k].value='';} }
for(const id of ids)nodes[id]=new Node(id);
let stored='',disk='',warnings=[];const listeners=[];const c={console,document:{getElementById:id=>nodes[id],querySelectorAll:()=>[]},confirm:()=>true,window:null};c.window=c;c.scrollTo=()=>{};
c.addEventListener=(name,fn)=>listeners.push(fn);
c.Native={load:()=>stored,save:s=>(stored=s,'OK'),loadSync:()=>disk,saveSync:s=>(disk=s,'OK'),sharedEndpoint:()=> 'https://script.google.com/macros/s/current/exec',sharedSignedIn:()=>false,warning:s=>warnings.push(s)};
vm.createContext(c);for(const name of [...html.matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]))vm.runInContext(fs.readFileSync(root+name,'utf8'),c,{filename:name});
a.equal(nodes.fatal.textContent,'','startup must not enter fatal read-only mode');a.equal(nodes.date.value,vm.runInContext('localVoucherDate()',c));
vm.runInContext("$('date').value='2020-01-01';clear()",c);a.equal(nodes.date.value,vm.runInContext('localVoucherDate()',c),'new voucher resets date');
vm.runInContext(`Shared.session=true;Shared.user={id:'admin',name:'Admin',role:'admin'};const initial=L.empty();L.initializeMaster(initial,{});L.fund(initial,{date:localDate(),amount:'100',reference:'Opening'});initial.funds[0].uid='database:fund:1';Offline.accept({revision:199,state:initial,databaseId:'database',user:Shared.user,reporting:{version:1,reports:[]}});PeriodUI.paint();`,c);
a.equal(nodes.submitPeriod.disabled,false);
console.log('PASS: complete Android HTML script order, startup, current local date, new-voucher reset, period controls and eligible submission state');
