$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
try {
  if (-not $env:JAVA_HOME) {
    $bundledJava = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
    if (Test-Path "$bundledJava\bin\java.exe") { $env:JAVA_HOME = $bundledJava }
  }
  if (-not $env:JAVA_HOME -or -not (Test-Path "$env:JAVA_HOME\bin\java.exe")) { throw 'Install Android Studio, or set JAVA_HOME to JDK 17 or 21.' }
  if (-not $env:ANDROID_HOME) { $env:ANDROID_HOME = Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
  if (-not (Test-Path "$env:ANDROID_HOME\platforms\android-35\android.jar")) { throw 'Install Android SDK Platform 35 in Android Studio > SDK Manager first.' }
  $buildTools = Join-Path $PSScriptRoot '.build-tools'
  New-Item -ItemType Directory -Force $buildTools | Out-Null
  $gradle = Join-Path $buildTools 'gradle-8.9\bin\gradle.bat'
  if (-not (Test-Path $gradle)) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $archive = Join-Path $buildTools 'gradle-8.9-bin.zip'
    Write-Host 'Downloading Gradle 8.9 (first build only)...'
    Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $archive
    $expected = (Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip.sha256').Content.Trim()
    if ((Get-FileHash $archive -Algorithm SHA256).Hash.ToLower() -ne $expected.ToLower()) { throw 'Gradle download checksum mismatch.' }
    Expand-Archive $archive -DestinationPath $buildTools -Force
  }
  Write-Host 'Building APK. First build downloads Android dependencies...'
  & $gradle --no-daemon assembleDebug
  if ($LASTEXITCODE -ne 0) { throw 'Android build failed. Read the error above.' }
  Copy-Item 'app\build\outputs\apk\debug\app-debug.apk' 'PrimeWay_Lollybird_Petty_Cash.apk' -Force
  Write-Host 'SUCCESS: PrimeWay_Lollybird_Petty_Cash.apk is ready in this folder.'
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
