/* Google Apps Script V8. Append the supplied Ledger.gs in the same project. */
function setupPrimeWay() {
 const p=PropertiesService.getScriptProperties();if(p.getProperty('DATABASE_ID'))throw Error('Already initialized.');
 const folder=DriveApp.createFolder('PrimeWay Lollybird Shared Petty Cash');
 const token=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');
 const db={revision:0,state:Ledger.empty(),users:[{id:Utilities.getUuid(),name:'Administrator',role:'admin',active:true,tokenHash:hashToken(token)}],audit:[]};
 Ledger.initializeMaster(db.state,AGENTS);
 const file=folder.createFile('database.json',JSON.stringify(db),'application/json');
 p.setProperties({DATABASE_ID:file.getId(),FOLDER_ID:folder.getId()});
 console.log('PRIVATE ADMIN ACCESS CODE (keep secret): '+token);console.log('Drive folder: '+folder.getUrl());
}
function hashToken(t){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(t)).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');}
function same(a,b){return stable(a)===stable(b);}
function stable(v){if(Array.isArray(v))return '['+v.map(stable).join(',')+']';if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}';return JSON.stringify(v);}
function publicUser(u){return {id:u.id,name:u.name,role:u.role,active:u.active};}
function transition(old,next,user){
 const s=JSON.parse(JSON.stringify(old));
 const allowed=['version','threshold','funds','vouchers','rates','masterVersion','agents','depots'];
 if(Object.keys(next).some(k=>!allowed.includes(k))||next.version!==1||next.masterVersion!==1)throw Error('Invalid ledger schema.');
 const changed=allowed.filter(k=>!same(old[k],next[k]));if(changed.length!==1&&!(changed.length===2&&changed.includes('agents')&&changed.includes('depots')))throw Error('Save one change at a time.');
 let action='';
 if(changed.includes('vouchers')){
  if(!['admin','editor','entry'].includes(user.role))throw Error('Your role cannot enter vouchers.');
  if(next.vouchers.length===old.vouchers.length+1&&same(next.vouchers.slice(0,-1),old.vouchers)){
   const v=next.vouchers[next.vouchers.length-1];validateVoucher(v);if(!v.reviewed)throw Error('Review all voucher fields before saving.');
   Ledger.add(s,{...v,amount:(v.amount/100).toFixed(2)});action='voucher.add';
  }else if(next.vouchers.length===old.vouchers.length&&['admin','editor'].includes(user.role)){
   const diffs=next.vouchers.map((v,i)=>same(v,old.vouchers[i])?-1:i).filter(i=>i>=0);if(diffs.length!==1)throw Error('Edit one voucher at a time.');
   const i=diffs[0],v=next.vouchers[i],previous=old.vouchers[i];validateVoucher(v);for(const k of ['photo','hash','voiceNote','cloudPhoto','cloudNote','createdBy','createdAt','updatedBy','updatedAt'])if(!same(v[k],previous[k]))throw Error('Source attachments and audit metadata cannot be changed.');if(!v.reviewed||v.id!==previous.id)throw Error('Invalid voucher edit.');
   Ledger.edit(s,v.id,{...v,amount:(v.amount/100).toFixed(2)});action='voucher.edit';
  }else throw Error('Your role cannot edit or remove saved vouchers.');
 }else{
  if(user.role!=='admin')throw Error('Only Admin can change cash, rates, agents, depots or settings.');
  if(changed[0]==='funds'&&next.funds.length===old.funds.length+1&&same(next.funds.slice(0,-1),old.funds)){
   const f=next.funds[next.funds.length-1];Ledger.fund(s,{...f,amount:(f.amount/100).toFixed(2)});action='cash.receive';
  }else if(changed[0]==='threshold'){s.threshold=Ledger.money((next.threshold/100).toFixed(2));action='threshold.change';
  }else if(changed[0]==='rates'){
   const differences=next.rates.filter(r=>!old.rates.some(x=>same(x,r)));if(differences.length!==1)throw Error('Change one rate at a time.');Ledger.setRate(s,differences[0].date,differences[0].rate);action='rate.change';
  }else if(changed[0]==='depots'&&next.depots.length===old.depots.length+1){const d=next.depots.find(x=>!old.depots.includes(x));Ledger.addDepot(s,d);action='depot.add';
  }else if(changed.includes('agents')){
   const diffs=next.agents.filter(a=>!old.agents.some(x=>same(x,a)));if(diffs.length!==1)throw Error('Change one agent at a time.');
   const removed=old.agents.filter(a=>!next.agents.some(x=>same(x,a)));if(removed.length>1)throw Error('Invalid agent change.');
   const a=diffs[0];Ledger.saveAgent(s,{...a,old_name:removed[0]?.name||''});action='agent.change';
  }else throw Error('Unsupported change.');
 }
 if(!same(s,next))throw Error('Validation failed: unexpected or inconsistent fields. Refresh and review.');
 return {state:s,action};
}
function validateVoucher(v){
 const keys=['number','date','paid_to','agent','depot','particulars','words','currency','amount','rate','photo','hash','voiceNote','reviewed','id','usd','cycle','cloudPhoto','cloudNote','createdBy','createdAt','updatedBy','updatedAt'];
 if(Object.keys(v).some(k=>!keys.includes(k)))throw Error('Unknown voucher field.');
 for(const k of ['number','paid_to','particulars','words'])if(typeof v[k]!=='string'||v[k].length>2000)throw Error('Invalid voucher text.');
 let words;try{words=InputHelpers.number(v.words.replace(/\bonly\b/gi,''));}catch{}
 if(words!==undefined&&Ledger.money(words)!==v.amount)throw Error('Amount in figures and words differ. Correct the voucher before saving.');
}
function doPost(e){
 const lock=LockService.getScriptLock();let locked=false;
 try{
  if(!e?.postData?.contents||e.postData.contents.length>16000000)throw Error('Request missing or too large.');
  const q=JSON.parse(e.postData.contents);if(!/^[a-f0-9]{64}$/i.test(q.token||''))throw Error('Access denied.');
  lock.waitLock(25000);locked=true;
  const p=PropertiesService.getScriptProperties(),file=DriveApp.getFileById(p.getProperty('DATABASE_ID')),db=JSON.parse(file.getBlob().getDataAsString());
  const u=db.users.find(x=>x.active&&x.tokenHash===hashToken(q.token));if(!u)throw Error('Access denied: wrong or revoked access code.');
  const response=()=>({ok:true,revision:db.revision,state:db.state,user:publicUser(u),users:u.role==='admin'?db.users.map(publicUser):[],audit:u.role==='admin'?db.audit.slice(-100):[]});
  if(q.action==='load')return output(response());
  if(q.action==='attachment'){
   const refs=db.state.vouchers.flatMap(v=>[v.cloudPhoto,v.cloudNote]).filter(Boolean);if(!refs.includes(q.fileId))throw Error('Attachment not in this database.');
   const blob=DriveApp.getFileById(q.fileId).getBlob();return output({ok:true,data:Utilities.base64Encode(blob.getBytes())});
  }
  if(q.revision!==db.revision)return output({ok:false,conflict:true,error:'Another user saved a change. Your form is kept. Refresh shared data and retry.'});
  let action,issuedToken;
  if(q.action==='save'){
   const t=transition(db.state,q.state,u);action=t.action;
   // Existing media references cannot be changed by an edit. New attachments are validated and private.
   if(action==='voucher.add'){
    const v=t.state.vouchers[t.state.vouchers.length-1];if(v.cloudPhoto||v.cloudNote||v.createdBy)throw Error('Invalid new attachment metadata.');
    const folder=DriveApp.getFolderById(p.getProperty('FOLDER_ID'));
    for(const [key,field,mime] of [['photo','cloudPhoto','image/jpeg'],['note','cloudNote','audio/mp4']]){
     const data=q.attachments?.[key];if(v[key==='photo'?'photo':'voiceNote']&&!data)throw Error('Attachment missing. Please retry.');
     if(data){if(typeof data!=='string'||data.length>11000000||!/^[A-Za-z0-9+/=]+$/.test(data))throw Error('Attachment too large or invalid.');
      const blob=Utilities.newBlob(Utilities.base64Decode(data),mime,'PCV_'+v.number.replace(/[^A-Za-z0-9_-]/g,'_')+'_'+Utilities.getUuid()+(key==='photo'?'.jpg':'.m4a'));
      v[field]=folder.createFile(blob).getId();
     }
    }
    v.createdBy=u.name;v.createdAt=new Date().toISOString();
   }
   if(action==='voucher.edit'){const v=t.state.vouchers.find((v,i)=>!same(v,db.state.vouchers[i]));v.updatedBy=u.name;v.updatedAt=new Date().toISOString();}
   db.state=t.state;
  }else if(q.action==='user.add'){
   if(u.role!=='admin')throw Error('Admin required.');const name=String(q.name||'').trim();if(!name||name.length>100||!['admin','editor','entry','viewer'].includes(q.role))throw Error('Enter name and valid role.');
   if(db.users.some(x=>x.active&&x.name.toLowerCase()===name.toLowerCase()))throw Error('User name already exists.');
   issuedToken=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');db.users.push({id:Utilities.getUuid(),name,role:q.role,active:true,tokenHash:hashToken(issuedToken)});action='user.add';
  }else if(q.action==='user.update'){
   if(u.role!=='admin')throw Error('Admin required.');const target=db.users.find(x=>x.id===q.userId);if(!target||!['admin','editor','entry','viewer'].includes(q.role)||typeof q.active!=='boolean')throw Error('Invalid user change.');
   if(target.id===u.id)throw Error('Ask another admin to change your own account.');
   if(target.role==='admin'&&target.active&&(q.role!=='admin'||!q.active)&&db.users.filter(x=>x.active&&x.role==='admin').length<=1)throw Error('Keep at least one active admin.');
   target.role=q.role;target.active=q.active;action='user.update';
  }else throw Error('Unknown operation.');
  const prior=file.getBlob();DriveApp.getFolderById(p.getProperty('FOLDER_ID')).createFile(Utilities.newBlob(prior.getBytes(),'application/json','revision_'+db.revision+'.json'));
  db.revision++;db.audit.push({revision:db.revision,at:new Date().toISOString(),by:u.name,action});if(db.audit.length>2000)db.audit=db.audit.slice(-2000);
  file.setContent(JSON.stringify(db));return output({...response(),issuedToken});
 }catch(err){return output({ok:false,error:String(err.message||err)});}finally{if(locked)lock.releaseLock();}
}
function output(value){return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);}
