(function(g){
const units=Object.fromEntries('zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen'.split(' ').map((x,i)=>[x,i]));
const tens=Object.fromEntries('twenty thirty forty fifty sixty seventy eighty ninety'.split(' ').map((x,i)=>[x,20+i*10]));
const months=Object.fromEntries('january february march april may june july august september october november december'.split(' ').map((x,i)=>[x,i+1]));
const ordinal={first:'one',second:'two',third:'three',fourth:'four',fifth:'five',sixth:'six',seventh:'seven',eighth:'eight',ninth:'nine',tenth:'ten',eleventh:'eleven',twelfth:'twelve',thirteenth:'thirteen',fourteenth:'fourteen',fifteenth:'fifteen',sixteenth:'sixteen',seventeenth:'seventeen',eighteenth:'eighteen',nineteenth:'nineteen',twentieth:'twenty',thirtieth:'thirty'};
function number(text,digits=false){
 text=text.toLowerCase().replace(/\b(?:liberian dollars?|us dollars?|united states dollars?|dollars?|usd|ld)\b/g,'').trim();if(/^\d[\d,]*(\.\d+)?$/.test(text))return text.replaceAll(',','');
 const tokens=(text.match(/[a-z]+|\d+/g)||[]).filter(x=>!['and','the','of'].includes(x)).map(x=>ordinal[x]||x);
 if(!tokens.length)throw Error('No number recognized.');
 if(digits&&tokens.every(x=>(units[x]!==undefined&&units[x]<10)||/^\d$/.test(x)))return tokens.map(x=>/^\d$/.test(x)?x:String(units[x])).join('');
 const point=tokens.indexOf('point');if(point>=0)return number(tokens.slice(0,point).join(' '))+'.'+number(tokens.slice(point+1).join(' '),true);
 let total=0,current=0;for(const t of tokens){if(/^\d+$/.test(t))current+=Number(t);else if(units[t]!==undefined)current+=units[t];else if(tens[t])current+=tens[t];else if(t==='hundred')current=Math.max(1,current)*100;else if(['thousand','million'].includes(t)){total+=Math.max(1,current)*(t==='thousand'?1000:1000000);current=0;}else throw Error('Number unclear; correct the recognized text.');}return String(total+current);
}
function voice(field,text,L){
 text=text.trim().replace(/\.$/,'');if(field==='number')return number(text,true);if(field==='amount'){if(/\d.*\b(?:LD|USD|dollars?)\b.*\d/i.test(text))throw Error('Split amount is ambiguous. Enter the full amount manually.');return number(text);}
 if(field==='currency'){if(/\bliberian\b|\bld\b|\bl\s+d\b/i.test(text))return 'LD';if(/\bunited states\b|\busd\b|\bu\s+s\b|\bus dollars?/i.test(text))return 'USD';throw Error('Say Liberian dollars or United States dollars.');}
 if(field==='date'){try{return L.validDate(text);}catch{}for(const [name,m] of Object.entries(months)){const match=text.match(new RegExp('\\b'+name+'\\b','i'));if(match)return L.validDate(number(text.slice(0,match.index).replace(/[,]/g,'').trim())+'-'+m+'-'+number(text.slice(match.index+name.length).replace(/[,]/g,'').trim()));}throw Error('Say: seven October two thousand twenty six.');}return text;
}
const boxes={number:[.775,.245,.925,.345],date:[.09,.265,.30,.365],paid_to:[.12,.38,.95,.455],words:[.16,.465,.96,.55],particulars:[.155,.555,.96,.64],amount:[.035,.745,.27,.845]};
function cloud(result,L){
 const text=result.content||'',v=L.extract(text),regions={},notes=[];const page=result.pages?.[0];
 if(page){for(const [key,b] of Object.entries(boxes)){const found=(page.words||[]).map(word=>{const p=word.polygon||[];if(p.length<8)return null;const x=(p[0]+p[2]+p[4]+p[6])/4/page.width,y=(p[1]+p[3]+p[5]+p[7])/4/page.height;return x>=b[0]&&x<=b[2]&&y>=b[1]&&y<=b[3]?{x,y,word}:null;}).filter(Boolean).sort((a,b)=>Math.round(a.y/.025)-Math.round(b.y/.025)||a.x-b.x);regions[key]=found.map(x=>x.word.content).join(' ');if(found.some(x=>(x.word.confidence??1)<.8))notes.push('Review low-confidence '+key);}}
 if(regions.number){const nums=regions.number.match(/\b\d{3,10}\b/g)||[];if(new Set(nums).size===1)v.number=nums[0];}
 if(regions.date){const candidates=regions.date.match(/\d{4}\s*[-/.]\s*\d{1,2}\s*[-/.]\s*\d{1,2}|\d{1,2}\s*[-/.,]\s*\d{1,2}\s*[-/.,]\s*\d{4}/g)||[];const dates=new Set();for(const t of candidates)try{dates.add(L.validDate(t.replace(/\s/g,'')));}catch{}if(dates.size===1)v.date=[...dates][0];else if(dates.size>1){delete v.date;notes.push('Overwritten date — confirm manually');}}
 for(const k of ['paid_to','words','particulars'])if(regions[k])v[k]=regions[k];
 if(regions.amount){const nums=regions.amount.match(/\d[\d,]*(?:\.\d{1,2})?/g)||[];if(new Set(nums).size>1){delete v.amount;notes.push('More than one amount — confirm manually');}else Object.assign(v,L.extract('Amount in Figure: '+regions.amount));}
 const amountSource=regions.amount||((text.match(/amount\s+in\s+figures?\s*[:_ -]*([^\n]+)/i)||[])[1]||'');
 const count=(amountSource.match(/\d[\d,]*(?:\.\d+)?/g)||[]).length;
 if(count!==1 || notes.some(n=>n==='Review low-confidence amount')){delete v.amount;notes.push('Amount requires manual confirmation; do not join separated figures automatically');}
 if(/\bLD\b|L\s*\$/i.test(amountSource)&&/\bUSD\b|US\s*\$/i.test(amountSource)){delete v.currency;notes.push('Conflicting currencies — choose from the photo');}
 if(!v.currency&&!notes.some(n=>n.startsWith('Conflicting currencies')))v.currency=L.extract('The Sum of: '+(regions.words||'')).currency;
 let wordsAmount;try{wordsAmount=number(v.words||'');}catch{}
 if(v.amount&&wordsAmount&&L.money(v.amount)!==L.money(wordsAmount)){delete v.amount;notes.push('Amount in figures differs from amount in words — confirm from photo');}
 return {fields:v,text:text+'\n\nONLINE FIELD TEXT\n'+Object.entries(regions).map(([k,t])=>k+': '+t).join('\n')+'\n'+notes.join('\n'),notes};
}
const api={number,voice,cloud};if(typeof module!=='undefined')module.exports=api;else g.InputHelpers=api;
})(typeof window!=='undefined'?window:globalThis);
