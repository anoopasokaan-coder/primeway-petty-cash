'use strict';
const Shared={required:false,session:false,revision:0,user:null,pending:new Map(),writing:false,
 initialize(){this.required=!!native().sharedEndpoint();$('sharedUrl').value=native().sharedEndpoint();this.paint();},
 canEdit(){return !this.required||(this.session&&['admin','editor'].includes(this.user.role));},
 request(q){return new Promise((resolve,reject)=>{
  const write=!['load','attachment'].includes(q.action);if(write&&(this.writing||this.pending.size))return reject(Error('Wait for the current save to finish.'));
  if(write)this.writing=true;
  const id=String(Date.now())+'_'+Math.random().toString(36).slice(2);this.pending.set(id,{resolve,reject,write});
  $('sharedBanner').textContent=write?'Saving to Google Drive — wait for confirmation…':'Reading shared database…';
  try{native().sharedRequest(JSON.stringify(q),id);}catch(e){this.pending.delete(id);if(write)this.writing=false;reject(e);}
 });},
 accept(r){if(this.session&&r.revision<this.revision)return;if(this.session&&this.revision!==r.revision)$('reviewed').checked=false;this.session=true;this.required=true;this.revision=r.revision;this.user=r.user;state=r.state;
  const saved=native().save(JSON.stringify(state));render();this.paint();
  if(saved!=='OK')$('sharedStatus').textContent='Saved on server; local cache failed. Refresh after reopening.';
  $('usersPanel').hidden=r.user.role!=='admin';
  $('usersList').innerHTML=(r.users||[]).map(u=>'<div class="entry"><b>'+L.esc(u.name)+'</b> · '+L.esc(u.role)+' · '+(u.active?'Active':'Revoked')+(u.id!==r.user.id?'<select data-role="'+L.esc(u.id)+'">'+['entry','editor','viewer','admin'].map(role=>'<option'+(role===u.role?' selected':'')+'>'+role+'</option>').join('')+'</select><button data-user="'+L.esc(u.id)+'" data-active="'+(!u.active)+'">'+(u.active?'Revoke access':'Reactivate')+'</button><button data-update="'+L.esc(u.id)+'">Save role</button>':'')+'</div>').join('');
  $('auditList').innerHTML=(r.audit||[]).slice().reverse().map(a=>'<p>'+L.esc(a.at)+' · '+L.esc(a.by)+' · '+L.esc(a.action)+' · #'+a.revision+'</p>').join('');
  $('usersList').querySelectorAll('[data-user],[data-update]').forEach(b=>b.onclick=async()=>{try{const id=b.dataset.user||b.dataset.update,u=r.users.find(u=>u.id===id);const role=$('usersList').querySelector('[data-role="'+id+'"]').value;const result=await this.request({action:'user.update',revision:this.revision,userId:id,role,active:b.dataset.user?b.dataset.active==='true':u.active});this.accept(result);}catch(e){native().warning(e.message);}});
 },
 paint(){const role=this.user?.role;const message=this.session?this.user.name+' · '+role+' · shared revision '+this.revision:this.required?'Shared database: sign in required. Cached data only; saving is disabled.':'Local device database. Connect in Settings for shared cash.';
  $('sharedStatus').textContent=message;$('sharedBanner').textContent=message;
  const canAdd=!this.required||(this.session&&['admin','editor','entry'].includes(role));$('save').disabled=!canAdd||busy;
  for(const section of ['cash','master'])$(section).querySelectorAll('input,select,button').forEach(e=>e.disabled=this.required&&(!this.session||role!=='admin'));
  $('usersPanel').hidden=!this.session||role!=='admin';entries();
 }
};
window.onShared=r=>{const p=Shared.pending.get(r.requestId);if(!p)return;Shared.pending.delete(r.requestId);if(p.write)Shared.writing=false;
 if(r.ok)p.resolve(r);else {Shared.paint();p.reject(Error(r.error||'Shared service failed.'));}
};
window.addEventListener('DOMContentLoaded',()=>{
 $('sharedForm').onsubmit=async e=>{e.preventDefault();try{if(Shared.pending.size)throw Error('Wait for the current request to finish.');Shared.revision=0;const result=native().sharedConfigure($('sharedUrl').value,$('sharedToken').value);if(result!=='OK')throw Error(result);Shared.required=true;Shared.session=false;Shared.paint();const r=await Shared.request({action:'load'});Shared.accept(r);$('sharedToken').value='';}catch(e){$('sharedStatus').textContent=e.message;}};
 $('sharedRefresh').onclick=async()=>{try{if(Shared.writing)throw Error('Wait for saving to finish.');Shared.accept(await Shared.request({action:'load'}));}catch(e){$('sharedStatus').textContent=e.message;}};
 $('sharedLogout').onclick=()=>{if(Shared.writing||Shared.pending.size)return native().warning('Wait for the current request to finish.');native().sharedSignOut();Shared.session=false;Shared.user=null;Shared.paint();};
 setInterval(async()=>{if(!Shared.session||document.hidden||busy||Shared.pending.size)return;try{Shared.accept(await Shared.request({action:'load'}));}catch(e){$('sharedStatus').textContent=e.message;}},60000);
 $('userForm').onsubmit=async e=>{e.preventDefault();try{const r=await Shared.request({action:'user.add',revision:Shared.revision,name:$('userName').value,role:$('userRole').value});Shared.accept(r);$('issuedCode').value=r.issuedToken;$('userName').value='';}catch(e){native().warning(e.message);}};
});
