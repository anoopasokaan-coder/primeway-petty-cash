package com.primeway.pettycash;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import androidx.exifinterface.media.ExifInterface;

class OnlineReader {
    static String endpoint(String value)throws Exception{
        URI u=new URI(value.trim());String host=u.getHost();
        if(!"https".equals(u.getScheme()) || host==null || !(host.endsWith(".cognitiveservices.azure.com")||host.endsWith(".services.ai.azure.com")) || u.getUserInfo()!=null || (u.getPort()!=-1 && u.getPort()!=443) || u.getQuery()!=null || u.getFragment()!=null || !(u.getPath().isEmpty()||"/".equals(u.getPath())))throw new IOException("Enter your HTTPS Azure resource endpoint.");
        return "https://"+host;
    }
    static JSONObject analyze(File photo,String service,String key)throws Exception{
        service=endpoint(service);if(key.trim().isEmpty())throw new IOException("Enter your Azure API key in settings.");
        BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;BitmapFactory.decodeFile(photo.getPath(),options);options.inSampleSize=Math.max(1,Math.max(options.outWidth,options.outHeight)/2400);options.inJustDecodeBounds=false;
        Bitmap image=BitmapFactory.decodeFile(photo.getPath(),options);if(image==null)throw new IOException("Cannot decode photo");
        int o=new ExifInterface(photo).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL);Matrix m=new Matrix();if(o==6)m.postRotate(90);if(o==3)m.postRotate(180);if(o==8)m.postRotate(270);image=Bitmap.createBitmap(image,0,0,image.getWidth(),image.getHeight(),m,true);
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();image.compress(Bitmap.CompressFormat.JPEG,94,bytes);
        if(bytes.size()>4000000)throw new IOException("Photo is too large. Select a smaller image.");
        HttpURLConnection c=connection(service+"/documentintelligence/documentModels/prebuilt-read:analyze?api-version=2024-11-30",key);
        String operation;
        try{c.setRequestMethod("POST");c.setRequestProperty("Content-Type","application/octet-stream");c.setDoOutput(true);try(OutputStream out=c.getOutputStream()){out.write(bytes.toByteArray());}if(c.getResponseCode()!=202)throw failure(c.getResponseCode());operation=c.getHeaderField("Operation-Location");}finally{c.disconnect();}
        if(operation==null)throw new IOException("Azure did not return an analysis job.");
        URI op=new URI(operation),base=new URI(service);if(!"https".equals(op.getScheme())||!base.getHost().equals(op.getHost())||op.getUserInfo()!=null||(op.getPort()!=-1&&op.getPort()!=443))throw new IOException("Unexpected result URL.");
        long deadline=System.currentTimeMillis()+120000;
        while(System.currentTimeMillis()<deadline){Thread.sleep(1500);c=connection(operation,key);
            try{if(c.getResponseCode()!=200)throw failure(c.getResponseCode());JSONObject result=new JSONObject(read(c.getInputStream()));String status=result.optString("status");if("succeeded".equals(status))return result.getJSONObject("analyzeResult");if("failed".equals(status)||"canceled".equals(status))throw new IOException("Azure could not read this photo.");}finally{c.disconnect();}
        }
        throw new IOException("Online OCR timed out. Retrying may count as another request.");
    }
    static HttpURLConnection connection(String url,String key)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(30000);c.setReadTimeout(30000);c.setRequestProperty("Ocp-Apim-Subscription-Key",key.trim());return c;}
    static IOException failure(int code){return new IOException(code==401?"Azure key does not match the endpoint.":code==429?"Azure request limit reached. Wait and retry.":"Azure returned HTTP "+code+". Check resource settings.");}
    static String read(InputStream in)throws IOException{try(InputStream stream=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=stream.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}}
}
