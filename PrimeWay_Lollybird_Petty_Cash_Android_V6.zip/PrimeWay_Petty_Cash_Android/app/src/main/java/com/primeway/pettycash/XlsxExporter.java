package com.primeway.pettycash;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.*;
final class XlsxExporter {
 static void write(File file,String[][] rows)throws IOException {
  try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(file))){
   put(z,"[Content_Types].xml","<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
   put(z,"_rels/.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
   put(z,"xl/workbook.xml","<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Petty cash expenses\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
   put(z,"xl/_rels/workbook.xml.rels","<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
   StringBuilder sheet=new StringBuilder("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols><col min=\"1\" max=\"14\" width=\"22\" customWidth=\"1\"/></cols><sheetData>");
   for(int r=0;r<rows.length;r++){sheet.append("<row r=\"").append(r+1).append("\">");for(int c=0;c<rows[r].length;c++){
    String value=rows[r][c]==null?"":rows[r][c];String ref=column(c)+(r+1);
    if(r>0&&(c==8||c==9||c==10||c==11)&&value.matches("-?\\d+(\\.\\d+)?"))sheet.append("<c r=\"").append(ref).append("\"><v>").append(value).append("</v></c>");
    else sheet.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(escape(value)).append("</t></is></c>");
   }sheet.append("</row>");}
   sheet.append("</sheetData>");if(rows.length>0)sheet.append("<autoFilter ref=\"A1:").append(column(rows[0].length-1)).append(rows.length).append("\"/>");sheet.append("</worksheet>");put(z,"xl/worksheets/sheet1.xml",sheet.toString());
  }
 }
 static String column(int c){String s="";for(c++;c>0;c=(c-1)/26)s=(char)('A'+(c-1)%26)+s;return s;}
 static String escape(String v){return v.replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]","").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");}
 static void put(ZipOutputStream z,String name,String content)throws IOException{z.putNextEntry(new ZipEntry(name));z.write(content.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
}
