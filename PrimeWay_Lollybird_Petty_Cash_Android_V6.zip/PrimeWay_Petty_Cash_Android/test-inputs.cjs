const assert=require('node:assert/strict'),L=require('./app/src/main/assets/ledger.js'),I=require('./app/src/main/assets/input_helpers.js');
assert.equal(I.voice('number','six three one five',L),'6315');assert.equal(I.voice('number','6 3 1 5',L),'6315');
assert.equal(I.voice('date','seven October two thousand twenty six',L),'2026-10-07');assert.equal(I.voice('amount','three hundred and sixty Liberian dollars',L),'360');assert.equal(I.voice('amount','twelve point five zero',L),'12.50');assert.equal(I.voice('currency','Liberian dollars',L),'LD');assert.equal(I.voice('currency','United States dollars',L),'USD');assert.equal(I.voice('paid_to','Benedict',L),'Benedict');
const words=[['6315',.84,.30],['2026-10-7',.2,.31],['Benadict',.25,.42],['Three',.2,.51],['hundred',.27,.51],['sixty',.34,.51],['LD',.40,.51],['Loading',.2,.60],['fee',.28,.60],['36',.34,.60],['bags',.40,.60],['360',.10,.79],['LD',.18,.79]].map(([content,x,y])=>({content,confidence:.95,polygon:[(x-.01)*1600,(y-.01)*800,(x+.01)*1600,(y-.01)*800,(x+.01)*1600,(y+.01)*800,(x-.01)*1600,(y+.01)*800]}));
const read=I.cloud({content:'PCV No: 6315',pages:[{width:1600,height:800,words}]},L);assert.equal(read.fields.date,'2026-10-07');assert.equal(read.fields.amount,'360');assert.equal(read.fields.currency,'LD');assert.equal(read.fields.number,'6315');assert.equal(read.fields.paid_to,'Benadict');assert.equal(read.fields.particulars,'Loading fee 36 bags');
console.log('PASS: spoken numbers, spoken date/currency, cloud region mapping and money/date fields. Real microphone/API accuracy remains untested.');

assert.throws(()=>I.voice('amount','200 LD 50',L),/ambiguous/);
const splitWords=words.filter(w=>!['360','LD'].includes(w.content)||w.polygon[1]<600);
for(const [content,x] of [['200',.09],['LD',.15],['50',.21]])splitWords.push({content,confidence:.95,polygon:[x*1600,620,(x+.02)*1600,620,(x+.02)*1600,650,x*1600,650]});
const split=I.cloud({content:'Amount in Figure: 200 LD 50',pages:[{width:1600,height:800,words:splitWords}]},L);assert.equal(split.fields.amount,undefined);assert.ok(split.notes.some(n=>/manual/.test(n)));
assert.equal(I.cloud({content:'Amount in Figure: 200 LD 50'},L).fields.amount,undefined);
console.log('PASS: split OCR amount 200 LD 50 withheld, with and without field geometry; split voice amount rejected.');
