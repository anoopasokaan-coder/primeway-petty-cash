'use strict';
// One atomic envelope owns the acknowledged server snapshot and the durable outbox.
const Offline={data:null,syncing:false,
 clone(x){return JSON.parse(JSON.stringify(x));},
 init(){const raw=native().loadSync();if(raw==='READ_ERROR')throw Error('Local pending vouchers cannot be read. Do not uninstall; recover the backup.');if(raw){this.data=JSON.parse(raw);if(this.data.version!==1||!Array.isArray(this.data.queue)||!this.data.server)throw Error('Unsupported local synchronization file.');if(this.data.endpoint!==native().sharedEndpoint())throw Error('Database address changed. Restore the previous address to recover pending vouchers.');if(native().sharedSignedIn()){Shared.session=true;Shared.user=this.data.server.user;Shared.revision=this.data.server.revision;this.project();render();}}},
 persist(next){const r=native().saveSync(JSON.stringify(next));if(r!=='OK')throw Error(r);this.data=next;},
 project(){if(!this.data)return;state=this.clone(this.data.server.state);for(const op of this.data.queue){if(op.kind==='add'){try{L.add(state,op.voucher);state.vouchers[state.vouchers.length-1].id=op.localId;}catch{ /* A server duplicate is retained in the queue for explicit review. */ }}else{try{L.edit(state,op.base.id,op.voucher);}catch{ /* Keep unresolved correction in outbox even if remote voucher is absent. */ }}}native().save(JSON.stringify(state));},
 count(){return this.data?.queue.length||0;},
 accept(r){if(!this.data){if(state.vouchers.length&&!r.state.vouchers.length)throw Error('This device has earlier entries. Export its backup before connecting; no automatic import is performed.');}
 if(this.data&&(this.data.endpoint!==native().sharedEndpoint()||this.data.server.user.id!==r.user.id))throw Error('This local database belongs to another connection/user. Sign in with its original access code.');
 if(this.data&&r.revision<this.data.server.revision)return;
 const next=this.data?this.clone(this.data):{version:1,endpoint:native().sharedEndpoint(),queue:[],lastSync:'',server:null};next.server=this.clone(r);
 if(r.operationId)next.queue=next.queue.filter(o=>o.operationId!==r.operationId);
 next.lastSync=new Date().toISOString();this.persist(next);this.project();
 },
 async save(candidate){if(this.syncing)throw Error('Wait for synchronization to finish.');if(!this.data||!Shared.session)throw Error('Connect once to download the shared database before saving offline.');
 if(!['admin','editor','entry'].includes(Shared.user.role))throw Error('Your role cannot enter vouchers.');
 const before=state.vouchers,after=candidate.vouchers;let kind,v,base;
 if(after.length===before.length+1){kind='add';v=after[after.length-1];}
 else if(after.length===before.length){const diffs=after.filter((x,i)=>JSON.stringify(x)!==JSON.stringify(before[i]));if(diffs.length!==1)throw Error('Change one voucher at a time.');v=diffs[0];base=before.find(x=>x.id===v.id);kind='edit';if(base.id<0)throw Error('Synchronize this new voucher before editing it. Its local entry is retained.');if(!['admin','editor'].includes(Shared.user.role))throw Error('Editor role required.');if(this.data.queue.some(o=>o.kind==='edit'&&o.base.id===base.id))throw Error('A correction for this voucher is already pending. Synchronize or resolve it first.');}
 else throw Error('Unsupported offline change.');
 const raw={};for(const k of keys)raw[k]=k==='amount'?(v.amount/100).toFixed(2):v[k];for(const k of ['photo','hash','voiceNote','reviewed'])raw[k]=v[k];
 raw.cycle=v.cycle;
 const next=this.clone(this.data),operationId='op_'+Date.now()+'_'+Math.random().toString(36).slice(2)+'_'+Math.random().toString(36).slice(2);
 next.queue.push({operationId,kind,voucher:raw,...(base?{base:this.clone(base)}:{}),localId:-Date.now(),error:''});this.persist(next);this.project();render();Shared.paint();
 },
 async sync(){if(this.syncing)return;if(!Shared.session)throw Error('Sign in first.');if(Shared.pending.size)throw Error('Wait for the current request to finish.');this.syncing=true;Shared.paint();
 try{Shared.accept(await Shared.request({action:'load'}));
  for(const original of [...this.data.queue]){const op=this.data.queue.find(o=>o.operationId===original.operationId);if(!op)continue;try{const r=await Shared.request({action:'sync.voucher',operationId:op.operationId,kind:op.kind,voucher:op.voucher,...(op.base?{base:op.base}:{})});if(r.operationId!==op.operationId)throw Error('Server did not acknowledge this operation. Update the Google backend to V8.');Shared.accept(r);}catch(e){const next=this.clone(this.data),failed=next.queue.find(o=>o.operationId===op.operationId);if(failed){failed.error=e.message;this.persist(next);}throw e;}}
  Shared.accept(await Shared.request({action:'load'}));
 }finally{this.syncing=false;Shared.paint();}},
 paint(){const el=$('syncDetails');if(!el)return;el.textContent=this.data?'Last download: '+this.data.lastSync+' · '+this.count()+' pending change(s). Balance is estimated; other devices may have unsynchronized expenses.':'Connect once to download the existing shared database.';
 const list=$('pendingList');list.innerHTML=(this.data?.queue||[]).map(o=>'<div class="entry"><b>PCV '+L.esc(o.voucher.number)+' · '+o.kind+' · Pending</b><p>'+L.esc(o.error||'Saved on this device; waiting for Synchronize now.')+'</p>'+(o.error?'<button data-resolve="'+o.operationId+'">Review conflict</button>':'')+'</div>').join('');
 list.querySelectorAll('[data-resolve]').forEach(b=>b.onclick=()=>{const op=this.data.queue.find(o=>o.operationId===b.dataset.resolve);if(!op)return;const remote=this.data.server.state.vouchers.find(v=>v.id===op.base?.id||String(v.number).replace(/^0+/,'')===String(op.voucher.number).replace(/^0+/,''));native().warning('Pending PCV '+op.voucher.number+': '+op.voucher.amount+' '+op.voucher.currency+'; '+op.voucher.particulars+'\n'+(remote?'Shared voucher: '+(remote.amount/100).toFixed(2)+' '+remote.currency+'; '+remote.particulars:'Not found in the last shared download.')+'\nExport a backup before resolving. Use the shared ledger Edit button after dismissing this pending change.');if(confirm('Remove this pending change from the sync queue? The shared voucher will remain unchanged. Export a backup first if you need the pending correction.')){const next=this.clone(this.data);next.queue=next.queue.filter(o=>o.operationId!==op.operationId);this.persist(next);this.project();render();Shared.paint();}});
 $('sharedRefresh').disabled=this.syncing; $('syncNow').disabled=this.syncing||!Shared.session;
 }
};
