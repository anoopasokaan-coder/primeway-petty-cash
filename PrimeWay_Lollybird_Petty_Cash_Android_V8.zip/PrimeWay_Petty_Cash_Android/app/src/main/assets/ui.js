'use strict';
const $=id=>document.getElementById(id),L=Ledger;
let state,photo='',hash='',busy=false,readOnly=false,autoAgent=false,voiceNote='',editingId=null;
const keys=['number','date','paid_to','agent','depot','particulars','words','currency','amount','rate'];
function native(){if(typeof Native==='undefined')throw Error('Open this screen in the Android app.');return Native;}
function showTab(id){document.querySelectorAll('.view').forEach(e=>e.classList.toggle('active',e.id===id));document.querySelectorAll('[data-tab]').forEach(e=>e.classList.toggle('active',e.dataset.tab===id));}
async function mutate(fn){
 if(readOnly)throw Error('Ledger is read-only because loading failed.');
 if(Shared.required&&!Shared.session)throw Error('Sign in to shared cash in Settings.');
 const candidate=JSON.parse(JSON.stringify(state));fn(candidate);
 if(Shared.session&&JSON.stringify(candidate.vouchers)!==JSON.stringify(state.vouchers)){await Offline.save(candidate);}
 else if(Shared.session){if(Offline.count())throw Error('Synchronize pending vouchers before changing cash or master settings.');const result=await Shared.request({action:'save',revision:Shared.revision,state:candidate});Shared.accept(result);}
 else {const result=native().save(JSON.stringify(candidate));if(result!=='OK')throw Error(result);state=candidate;render();}
}

function currentReport(){const html=L.report(state,Number($('cycleList').value)||L.cycle(state));return Shared.required?html.replace('<h1>', '<p><b>PROVISIONAL: based on this device. '+Offline.count()+' pending change(s); last shared download '+L.esc(Offline.data?.lastSync||'none')+'. Other devices may have unsynchronized vouchers.</b></p><h1>'):html;}
function archive(){if(!L.cycle(state))return;const r=native().archive(L.report(state,L.cycle(state)).replace('<h1>','<p><b>PROVISIONAL — based on this device; synchronize all users before approval.</b></p><h1>'),L.cycle(state));if(r!=='OK')throw Error('Report archive failed: '+r);}
function clear(){if(busy)return;photo='';hash='';voiceNote='';editingId=null;$('save').textContent='Save reviewed voucher';autoAgent=false;$('voucherForm').reset();$('depot').readOnly=false;$('photo').hidden=true;$('photo').removeAttribute('src');$('fieldReview').hidden=true;$('raw').value='';$('voucherError').textContent='';$('noteShare').disabled=true;$('ocrStatus').textContent='Take a landscape photo with the voucher filling the frame. Check handwriting in the enlarged fields.';conversion();}
function conversion(){try{let cents=L.money($('amount').value);if($('currency').value==='LD'){const s=L.empty();L.fund(s,{date:'2026-01-01',amount:'1',reference:'preview'});L.add(s,{number:'preview',date:'2026-01-01',paid_to:'x',particulars:'x',words:'x',currency:'LD',amount:$('amount').value,rate:$('rate').value});cents=s.vouchers[0].usd;}else if($('currency').value!=='USD')throw Error();$('conversion').textContent='USD equivalent: US$ '+L.fmt(cents);}catch{$('conversion').textContent='USD equivalent: enter amount, currency and LD rate if needed.';}}
window.onPhoto=function(result){
 busy=false;['take','upload','save','clear','quickCamera','quickUpload'].forEach(id=>$(id).disabled=readOnly);
 if(result.photo){photo=result.photo;hash=result.hash||'';$('photo').src='https://app.local/photos/'+encodeURIComponent(photo);$('photo').hidden=false;}
 if(result.analysis){$('amount').value='';$('currency').value='';const read=InputHelpers.cloud(result.analysis,L);$('raw').value=read.text;for(const [k,x] of Object.entries(read.fields))if(x!==undefined)$(k).value=x;matchPayee();$('rate').value=L.rateFor(state,$('date').value);$('ocrStatus').textContent='Online fields filled. Verify every value; '+read.notes.join('. ');}
 if(result.text){
  const regions=result.regions||{};$('raw').value=result.text+'\n\nFIELD OCR CANDIDATES — NOT CONFIRMED\n'+Object.entries(regions).map(([k,v])=>k+': '+v).join('\n');
  const v=L.extract(result.text);for(const key of ['date','amount','currency'])delete v[key];
  if(regions.number){const n=regions.number.replace(/\s/g,'');if(/^\d{3,10}$/.test(n))v.number=n;else delete v.number;}
  for(const k of ['paid_to','words','particulars'])if(regions[k]&&/[A-Za-z]{3}/.test(regions[k]))v[k]=regions[k].trim();
  for(const [k,x] of Object.entries(v))$(k).value=x;
  matchPayee();
  $('ocrStatus').textContent='Printed number and handwriting suggestions extracted. Confirm date, Amount in Figure and LD/USD from the enlarged photo; unclear handwriting is not reliable.';
 }
 if(result.error)$('ocrStatus').textContent=result.error;
 $('reviewed').checked=false;conversion();
};
const boxes={number:[.775,.245,.925,.345],date:[.09,.265,.30,.365],paid_to:[.12,.38,.95,.455],words:[.16,.465,.96,.55],particulars:[.155,.555,.96,.64],amount:[.035,.745,.27,.845]};
function zoomField(){const im=$('photo');if(!im.naturalWidth)return;const box=boxes[$('region').value],c=$('zoom'),ctx=c.getContext('2d');const w=(box[2]-box[0])*im.naturalWidth,h=(box[3]-box[1])*im.naturalHeight;const scale=Math.min(4,Math.max(2,700/w));c.width=Math.round(w*scale);c.height=Math.round(h*scale);ctx.drawImage(im,box[0]*im.naturalWidth,box[1]*im.naturalHeight,w,h,0,0,c.width,c.height);$('fieldReview').hidden=false;}
$('photo').onload=zoomField;$('region').onchange=zoomField;
function take(kind){try{if(busy)return;clear();busy=true;['take','upload','save','clear','quickCamera','quickUpload'].forEach(id=>$(id).disabled=true);$('ocrStatus').textContent='Opening photo capture / selection…';native()[kind]();}catch(e){window.onPhoto({error:e.message});}}
function render(){
 renderMaster();
 $('balance').textContent='US$ '+L.fmt(L.balance(state));$('status').textContent=(L.cycle(state)?L.status(state):'Record opening cash to begin')+(Shared.required?' · ESTIMATED / LAST SYNC + LOCAL ENTRIES':'');$('summary').classList.toggle('low',L.cycle(state)>0&&L.balance(state)<=state.threshold);
 $('threshold').value=(state.threshold/100).toFixed(2);
 $('funds').innerHTML=state.funds.slice().reverse().map(f=>'<div class="entry"><b>Cycle '+f.id+' · US$ '+L.fmt(f.amount)+'</b><p>'+L.esc(f.date)+' · '+L.esc(f.reference)+'</p></div>').join('')||'<p>No cash received yet.</p>';
 $('rates').innerHTML=state.rates.map(r=>'<div class="entry">'+L.esc(r.date)+' · LD '+L.esc(r.rate)+' / USD</div>').join('');
 const selected=$('cycleList').value;$('cycleList').innerHTML=state.funds.map(f=>'<option value="'+f.id+'">Cycle '+f.id+' · '+L.esc(f.date)+'</option>').join('');
 $('cycleList').value=state.funds.some(f=>String(f.id)===selected)?selected:String(L.cycle(state));reportPreview();entries();
}
function entries(){
 const q=$('search').value.toLowerCase();const rows=state.vouchers.filter(r=>[r.number,r.paid_to,r.particulars,r.depot].join(' ').toLowerCase().includes(q)).slice().reverse();
 $('entries').innerHTML=rows.map(r=>'<div class="entry"><strong>PCV '+L.esc(r.number)+'</strong> <b style="float:right">US$ '+L.fmt(r.usd)+'</b><p>'+L.esc(r.date)+' · '+L.esc(r.paid_to)+'</p><p>'+L.esc(r.particulars)+'</p><p class="muted">'+L.esc(r.currency)+' '+L.fmt(r.amount)+(r.rate?' · Rate '+L.esc(r.rate):'')+' · Cycle '+r.cycle+'</p>'+(Shared.canEdit()?'<button data-edit="'+r.id+'">Edit voucher</button>':'')+(r.voiceNote?'<button data-note="'+L.esc(r.voiceNote)+'">Share voice note</button>':'')+(r.photo?'<button data-photo="'+L.esc(r.photo)+'">View photo</button>':'')+'</div>').join('')||'<p>No matching vouchers.</p>';
 $('entries').querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>{if(busy)return;const selectedRow=state.vouchers.find(v=>v.id===Number(b.dataset.edit));if(selectedRow.id<0)return native().warning('Synchronize this pending new voucher before editing it.');clear();const r=state.vouchers.find(v=>v.id===Number(b.dataset.edit));for(const k of keys)$(k).value=k==='amount'?(r.amount/100).toFixed(2):(r[k]||'');editingId=r.id;photo=r.photo||'';hash=r.hash||'';voiceNote=r.voiceNote||'';$('save').textContent='Save reviewed correction';$('reviewed').checked=false;showTab('voucher');conversion();});
 $('entries').querySelectorAll('[data-note]').forEach(b=>b.onclick=async()=>{try{const r=state.vouchers.find(v=>v.voiceNote===b.dataset.note);if(Shared.session&&r.cloudNote)await Shared.request({action:'attachment',fileId:r.cloudNote,name:r.voiceNote,kind:'note'});native().shareNote(b.dataset.note);}catch(e){native().warning(e.message);}});
 $('entries').querySelectorAll('[data-photo]').forEach(b=>b.onclick=async()=>{try{if(busy)return;const r=state.vouchers.find(v=>v.photo===b.dataset.photo);if(Shared.session&&r.cloudPhoto)await Shared.request({action:'attachment',fileId:r.cloudPhoto,name:r.photo,kind:'photo'});showTab('voucher');clear();$('photo').src='https://app.local/photos/'+encodeURIComponent(b.dataset.photo);$('photo').hidden=false;$('ocrStatus').textContent='Saved voucher photo (reference only). Start a new capture to create another voucher.';}catch(e){native().warning(e.message);}});
}
function reportPreview(){try{$('preview').srcdoc=currentReport();$('print').disabled=false;$('shareReport').disabled=false;}catch{$('preview').srcdoc='<p>Record opening cash and save vouchers to begin.</p>';$('print').disabled=true;$('shareReport').disabled=true;}}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
$('take').onclick=()=>take('camera');$('upload').onclick=()=>take('gallery');$('clear').onclick=clear;
function matchPayee(){const a=L.resolveAgent(state,$('paid_to').value);if(a){autoAgent=true;$('agent').value=a.name;$('depot').value=a.depot;$('depot').readOnly=true;}else if(autoAgent){autoAgent=false;$('agent').value='';$('depot').value='';$('depot').readOnly=false;}}
function renderMaster(){
 const selected=$('agent').value,edit=$('masterAgent').value,assigned=$('assignedDepot').value;
 $('agent').innerHTML='<option value="">Other payee / no agent</option>'+state.agents.map(a=>'<option>'+L.esc(a.name)+'</option>').join('');
 const match=L.resolveAgent(state,selected);if(match){$('agent').value=match.name;$('depot').value=match.depot;$('depot').readOnly=true;}else{$('agent').value='';$('depot').readOnly=false;}
 $('masterAgent').innerHTML='<option value="">New agent</option>'+state.agents.map(a=>'<option>'+L.esc(a.name)+'</option>').join('');$('masterAgent').value=state.agents.some(a=>a.name===edit)?edit:'';
 $('assignedDepot').innerHTML='<option value="">Select depot</option>'+state.depots.map(d=>'<option>'+L.esc(d)+'</option>').join('');$('assignedDepot').value=state.depots.includes(assigned)?assigned:'';
 $('masterList').innerHTML=state.agents.map(a=>'<div class="entry"><b>'+L.esc(a.name)+'</b> → '+L.esc(a.depot)+(a.aliases.length?'<p class="muted">Aliases: '+L.esc(a.aliases.join(', '))+'</p>':'')+'</div>').join('');
 $('depotList').innerHTML=state.depots.map(d=>'<div class="entry">'+L.esc(d)+'</div>').join('');matchPayee();
}
function loadAgent(){const a=state.agents.find(x=>x.name===$('masterAgent').value);$('agentName').value=a?.name||'';$('assignedDepot').value=a?.depot||'';$('agentAliases').value=a?.aliases.join(', ')||'';}
$('masterAgent').onchange=loadAgent;$('newAgent').onclick=()=>{$('masterAgent').value='';loadAgent();};
$('agentForm').onsubmit=async e=>{e.preventDefault();try{const name=$('agentName').value.trim();await mutate(s=>L.saveAgent(s,{name,depot:$('assignedDepot').value,old_name:$('masterAgent').value,aliases:$('agentAliases').value.split(',')}));$('masterAgent').value=name;loadAgent();native().warning('Agent assignment saved for new vouchers.');}catch(err){native().warning(err.message);}};
$('depotForm').onsubmit=async e=>{e.preventDefault();try{const name=$('depotName').value.trim();await mutate(s=>L.addDepot(s,name));$('depotName').value='';$('assignedDepot').value=state.depots.find(d=>L.nameKey(d)===L.nameKey(name))||'';native().warning('Depot added. You can now assign an agent to it.');}catch(err){native().warning(err.message);}};
$('paid_to').addEventListener('input',matchPayee);
$('agent').onchange=()=>{autoAgent=false;const a=L.resolveAgent(state,$('agent').value);$('depot').value=a?.depot||'';$('depot').readOnly=!!a;if(a&&!$('paid_to').value)$('paid_to').value=a.name;};
$('date').onchange=()=>{$('rate').value=L.rateFor(state,$('date').value);conversion();};
['amount','rate','currency'].forEach(id=>$(id).addEventListener('input',conversion));
$('voucherForm').onsubmit=async e=>{e.preventDefault();if(busy)return;try{
 const v={};for(const k of keys)v[k]=$(k).value.trim();v.photo=photo;v.hash=hash;v.voiceNote=voiceNote;v.reviewed=$('reviewed').checked;if(!v.reviewed)throw Error('Review and confirm the voucher before saving.');
 let spoken;try{spoken=InputHelpers.number(v.words.replace(/\bonly\b/gi,''));}catch{}
 if(spoken!==undefined&&L.money(spoken)!==L.money(v.amount))throw Error('Amount in figures and amount in words differ. Check the photo and correct them.');
 await mutate(s=>editingId===null?L.add(s,v):L.edit(s,editingId,v));clear();
 if(L.balance(state)<=state.threshold){let text=L.status(state);try{archive();text+='\nAn approval report has been archived.';}catch(err){text+='\n'+err.message;}native().warning(text);$('cycleList').value=String(L.cycle(state));reportPreview();}
 else $('ocrStatus').textContent=Shared.session?'Saved on this device. Use Settings → Synchronize now to share it.':'Voucher saved. Take the next photo when ready.';
}catch(err){$('voucherError').textContent=err.message;}};
$('fundForm').onsubmit=async e=>{e.preventDefault();try{archive();await mutate(s=>L.fund(s,{amount:$('fundAmount').value,date:$('fundDate').value,reference:$('fundReference').value}));$('fundForm').reset();$('fundDate').value=localDate();$('cycleList').value=String(L.cycle(state));reportPreview();native().warning('Cash receipt recorded. New balance: US$ '+L.fmt(L.balance(state)));}catch(err){native().warning(err.message);}};
$('rateForm').onsubmit=async e=>{e.preventDefault();try{await mutate(s=>L.setRate(s,$('rateDate').value,$('newRate').value));$('rate').value=L.rateFor(state,$('date').value);conversion();native().warning('Exchange rate saved. Historical vouchers retain their rates.');}catch(err){native().warning(err.message);}};
$('thresholdForm').onsubmit=async e=>{e.preventDefault();try{await mutate(s=>{s.threshold=L.money($('threshold').value);});native().warning('Warning level saved.');}catch(err){native().warning(err.message);}};
$('search').oninput=entries;$('cycleList').onchange=reportPreview;
$('csv').onclick=()=>native().share(L.csv(state),'csv');$('backup').onclick=()=>native().backup();
$('print').onclick=()=>native().printReport(currentReport());$('shareReport').onclick=()=>native().share(currentReport(),'html');
function localDate(){const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');}
$('quickCamera').onclick=()=>{showTab('voucher');take('camera');};$('quickUpload').onclick=()=>{showTab('voucher');take('gallery');};$('quickVoice').onclick=()=>showTab('voice');$('quickReader').onclick=()=>showTab('settings');
$('xlsx').onclick=()=>{const columns=['date','number','paid_to','agent','depot','particulars','words','currency','amount','rate','usd','cycle','photo','voiceNote'];const rows=[columns.map(k=>k.toUpperCase()),...state.vouchers.map(r=>columns.map(k=>k==='amount'||k==='usd'?(r[k]/100).toFixed(2):String(r[k]??'')))];native().share(JSON.stringify(rows),'xlsx');};
$('noteStart').onclick=()=>{try{native().recordNote($('voiceField').value);}catch(e){$('noteStatus').textContent=e.message;}};
$('noteStop').onclick=()=>native().stopNote();$('noteShare').onclick=()=>{if(voiceNote)native().shareNote(voiceNote);};
window.onNoteState=r=>{busy=r.state==='recording'||r.state==='reading';$('noteStart').disabled=busy;$('noteStop').disabled=r.state!=='recording';['take','upload','save','clear','quickCamera','quickUpload'].forEach(id=>$(id).disabled=busy||readOnly);$('noteStatus').textContent=r.message;if(r.file){voiceNote=r.file;$('noteShare').disabled=false;}};
$('onlineForm').onsubmit=async e=>{e.preventDefault();try{if(!Shared.session||Shared.user.role!=='admin')throw Error('Sign in as administrator to change Azure settings.');const r=await Shared.request({action:'reader.settings',endpoint:$('onlineEndpoint').value.trim(),key:$('onlineKey').value.trim(),enabled:$('onlineEnabled').checked});Shared.accept(r);$('onlineKey').value='';$('onlineForm').hidden=true;}catch(err){$('onlineStatus').textContent=err.message;}};
$('voiceStart').onclick=()=>{try{$('voiceStatus').textContent='Speak into the microphone…';native().voice($('voiceField').value,$('voiceLanguage').value,$('voiceOffline').checked);}catch(err){$('voiceStatus').textContent=err.message;}};
window.onVoice=function(result){if(result.note){voiceNote=result.note;$('noteShare').disabled=false;}if(result.error){$('voiceStatus').textContent=result.error;return;}$('voiceField').value=result.field;$('voiceText').value=result.text;$('voiceAlternatives').innerHTML='';for(const t of result.alternatives||[result.text]){const o=document.createElement('option');o.textContent=t;o.value=t;$('voiceAlternatives').append(o);}$('voiceStatus').textContent='Review the recognized text, then Apply.';};
$('voiceAlternatives').onchange=()=>{$('voiceText').value=$('voiceAlternatives').value;};
$('voiceApply').onclick=()=>{try{if(busy)throw Error('Wait for photo reading to finish.');const k=$('voiceField').value;$(k).value=InputHelpers.voice(k,$('voiceText').value,L);matchPayee();if(k==='date')$('rate').value=L.rateFor(state,$('date').value);conversion();$('voiceStatus').textContent='Applied. Verify before saving.';}catch(err){$('voiceStatus').textContent=err.message;}};
try{
 const data=native().load();if(data==='READ_ERROR')throw Error('Stored ledger could not be read. Do not uninstall the app; recover your backup with support.');
 state=data?JSON.parse(data):L.empty();if(state.version!==1||!Array.isArray(state.funds)||!Array.isArray(state.vouchers)||!Array.isArray(state.rates))throw Error('Unsupported ledger format.');
 if(L.initializeMaster(state,AGENTS)){const result=native().save(JSON.stringify(state));if(result!=='OK')throw Error(result);}
 $('fundDate').value=localDate();$('rateDate').value=localDate();render();Shared.initialize();
}catch(e){readOnly=true;$('fatal').textContent=e.message;document.querySelectorAll('button,input,select,textarea').forEach(x=>x.disabled=true);}
