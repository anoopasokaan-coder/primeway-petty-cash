(function(global){
'use strict';
function decimal(v,places){
 const s=String(v).trim(); if(!/^\d+(\.\d+)?$/.test(s))throw Error('Enter a positive numeric value.');
 const [a,b='']=s.split('.'); if(b.length>places)throw Error('Too many decimal places.');
 const n=Number(a)*10**places+Number(b.padEnd(places,'0'));if(!Number.isSafeInteger(n)||n>1e12)throw Error('Amount exceeds supported range.');return n;
}
function money(v){return decimal(v,2);}
function validDate(s){s=String(s).trim();const iso=s.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/),m=s.match(/^(\d{1,2})\s*[-/.,\s]\s*(\d{1,2})\s*[-/.,\s]\s*(\d{4})$/);if(iso)s=iso[1]+'-'+iso[2].padStart(2,'0')+'-'+iso[3].padStart(2,'0');else if(m)s=m[3]+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0');if(!/^\d{4}-\d{2}-\d{2}$/.test(s)||!Number.isFinite(new Date(s+'T00:00:00Z').getTime())||new Date(s+'T00:00:00Z').toISOString().slice(0,10)!==s)throw Error('Use a valid day-month-year date, for example 7-10-2026.');return s;}
function empty(){return {version:1,threshold:5000,funds:[],vouchers:[],rates:[]};}
function balance(s){return s.funds.reduce((a,r)=>a+r.amount,0)-s.vouchers.reduce((a,r)=>a+r.usd,0);}
function cycle(s){return s.funds.length;}
function nameKey(v){return String(v||'').toLowerCase().replace(/[^\p{L}\p{N}\s]/gu,' ').trim().replace(/\s+/g,' ');}
function initializeMaster(s,seed){if(s.masterVersion===1)return false;s.agents=Object.entries(seed).map(([name,depot])=>({name,depot,aliases:[]}));s.depots=[...new Set(Object.values(seed))].sort();s.masterVersion=1;return true;}
function resolveAgent(s,name){const k=nameKey(name);if(!k)return null;return (s.agents||[]).find(a=>nameKey(a.name)===k||(a.aliases||[]).some(x=>nameKey(x)===k))||null;}
function addDepot(s,name){name=String(name).trim();if(!name)throw Error('Enter a depot name.');if(!(s.depots||[]).some(d=>nameKey(d)===nameKey(name)))s.depots.push(name);s.depots.sort();}
function saveAgent(s,v){
 const name=String(v.name||'').trim(),depot=String(v.depot||'').trim(),old=(s.agents||[]).find(a=>a.name===v.old_name);
 if(!name||!depot)throw Error('Agent name and assigned depot are required.');if(!(s.depots||[]).includes(depot))throw Error('Add the depot to the master first.');
 if(v.old_name&&!old)throw Error('Selected agent no longer exists.');
 const aliases=[...(v.aliases||[]),...(old?.aliases||[]),...(old&&old.name!==name?[old.name]:[])].map(x=>String(x).trim()).filter(x=>x&&nameKey(x)!==nameKey(name));
 for(const x of [name,...aliases]){const match=resolveAgent(s,x);if(match&&match!==old)throw Error('Name or alias already belongs to '+match.name);}
 const saved={name,depot,aliases:[...new Set(aliases)]};if(old)s.agents[s.agents.indexOf(old)]=saved;else s.agents.push(saved);s.agents.sort((a,b)=>a.name.localeCompare(b.name));
}
function status(s){const b=balance(s);return b<=0?'CASH FINISHED — REPLENISH NOW':b<=s.threshold?'TIME TO REPLENISH':'CASH AVAILABLE';}
function fund(s,v){const when=validDate(v.date);const amount=money(v.amount);if(!amount||!v.reference.trim())throw Error('Enter cash received and a receipt reference.');s.funds.push({id:cycle(s)+1,date:when,amount,reference:v.reference.trim()});}
function setRate(s,date,rate){date=validDate(date);const units=decimal(rate,6);if(!units)throw Error('Rate must be greater than zero.');s.rates=s.rates.filter(r=>r.date!==date);s.rates.push({date,rate:String(rate)});s.rates.sort((a,b)=>a.date.localeCompare(b.date));}
function rateFor(s,date){try{date=validDate(date);}catch{return '';}const r=s.rates.filter(r=>r.date<=date).sort((a,b)=>b.date.localeCompare(a.date))[0];return r?r.rate:'';}
function voucherKey(n){n=String(n).trim().replace(/\s/g,'').toUpperCase();return /^\d+$/.test(n)?n.replace(/^0+(?=\d)/,''):n;}
function add(s,v){
 if(!cycle(s))throw Error('Record opening cash received first.');v={...v,date:validDate(v.date)};
 const agent=resolveAgent(s,v.agent||v.paid_to);if(v.agent&&!agent)throw Error('Choose a master agent, or leave agent blank for another payee.');if(agent){v.agent=agent.name;v.depot=agent.depot;}
 for(const k of ['number','paid_to','particulars','words'])if(!String(v[k]||'').trim())throw Error('Required field: '+k);
 if(!['USD','LD'].includes(v.currency))throw Error('Choose USD or LD.');
 if(s.vouchers.some(r=>voucherKey(r.number)===voucherKey(v.number)||(v.hash&&r.hash===v.hash)))throw Error('Duplicate voucher number or photo.');
 const amount=money(v.amount);if(!amount)throw Error('Amount must be greater than zero.');
 let usd=amount,rate='';
 if(v.currency==='LD'){
  const units=decimal(v.rate,6);if(!units)throw Error('LD per USD must be positive.');rate=String(v.rate);
  // BigInt preserves exact integer arithmetic, including conversion rounding.
  usd=Number((BigInt(amount)*BigInt(1000000)+BigInt(units)/BigInt(2))/BigInt(units));
 }
 if(!Number.isSafeInteger(usd)||usd>1e12)throw Error('Converted amount exceeds supported range.');
 s.vouchers.push({...v,id:s.vouchers.length+1,number:v.number.trim(),amount,rate,usd,cycle:cycle(s)});
}
function edit(s,id,v){
 const index=s.vouchers.findIndex(r=>r.id===Number(id));if(index<0)throw Error('Voucher not found.');
 const old=s.vouchers[index],temp=JSON.parse(JSON.stringify(s));temp.vouchers.splice(index,1);
 add(temp,{...old,...v,photo:old.photo,hash:old.hash,voiceNote:old.voiceNote});
 const updated=temp.vouchers.pop();updated.id=old.id;updated.cycle=old.cycle;
 // Historical depot stays attached unless the user explicitly changes the agent.
 if(nameKey(old.agent)===nameKey(v.agent)){updated.agent=old.agent;updated.depot=old.depot;}
 s.vouchers[index]=updated;
}
function extract(t){
 const fields={number:/(?:\bP\s*C\s*[VB]\b\s*(?:no\.?|number|#)?|\bvoucher\s+(?:no\.?|number|#))\s*[:#_ -]*\s*([A-Za-z0-9/-]*\d[A-Za-z0-9/-]*)/i,date:/\bdate\s*[:_]*\s*(\d{4}-\d{2}-\d{2}|\d{1,2}\s*[-/.,\s]\s*\d{1,2}\s*[-/.,\s]\s*\d{4})/i,paid_to:/paid\s+to\s*[:._ -]*\s*([^\n]+)/i,particulars:/(?:payment\s+of|particulars|description|purpose)\s*[:._ -]*\s*([^\n]+)/i,words:/(?:the\s+sum\s+of|amount\s+in\s+words|in\s+words)\s*[:._ -]*\s*([^\n]+)/i,amount:/(?:amount\s+in\s+figures?|total\s+amount|amount\s+paid|amount)\s*[:=_ -]*\s*(?:USD|US\s*\$|LD|L\s*\$|\$)?\s*([0-9][0-9,]*(?:\.\d{1,2})?)/i};
 const v={};for(const [key,re] of Object.entries(fields)){const m=t.match(re);if(m)v[key]=key==='amount'?m[1].replaceAll(',',''):m[1].trim();}
 const amount=t.match(/amount\s+in\s+figures?\s*[:_ -]*\s*([^\n]+)/i);let source=amount&&/\bL\s*D\b|\bU\s*S\s*D\b|US\s*\$|L\s*\$/i.test(amount[1])?amount[1]:t;
 const usd=/\bU\s*S\s*D\b|U\s*S\s*\$/i.test(source),ld=/\bL\s*D\b|L\s*\$/i.test(source);if(usd!==ld)v.currency=usd?'USD':'LD';
 if(v.date){try{v.date=validDate(v.date);}catch{delete v.date;}}return v;
}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmt(n){return (n/100).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});}
function report(s,id){
 const f=s.funds.find(x=>x.id===Number(id));if(!f)throw Error('Select a valid cash cycle.');
 const rows=s.vouchers.filter(r=>r.cycle===f.id),total=rows.reduce((a,r)=>a+r.usd,0);
 const opening=s.funds.filter(r=>r.id<f.id).reduce((a,r)=>a+r.amount,0)-s.vouchers.filter(r=>r.cycle<f.id).reduce((a,r)=>a+r.usd,0);
 return '<!doctype html><html><head><meta charset="utf-8"><title>Petty Cash Summary</title><style>body{font:12px Arial;color:#102c48;margin:22px}h1{border-bottom:4px solid #087f69;padding-bottom:12px}table{width:100%;border-collapse:collapse;margin:18px 0}td,th{border:1px solid #ccd4dc;padding:7px;text-align:left;overflow-wrap:anywhere}th{background:#102c48;color:white}tr{break-inside:avoid}thead{display:table-header-group}.sign{display:flex;gap:20px;margin-top:65px;break-inside:avoid}.sign div{flex:1;border-top:1px solid;padding-top:12px}@page{size:A4 landscape;margin:12mm}@media print{body{font-size:10px;margin:0}}</style></head><body><h1>Petty Cash Summary for PrimeWay and Lollybird</h1><p>Cash cycle '+f.id+' • Receipt date '+esc(f.date)+' • Reference '+esc(f.reference)+'</p><p>Opening cash: US$ '+fmt(opening)+' | Cash received: US$ '+fmt(f.amount)+' | Expenses: US$ '+fmt(total)+' | Closing cash: US$ '+fmt(opening+f.amount-total)+'</p><table><thead><tr>'+['Date','PCV No','Paid to','Agent / depot','Particulars','Amount in words','Currency','Amount','LD per USD','USD expense'].map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+[r.date,r.number,r.paid_to,[r.agent,r.depot].filter(Boolean).join(' / '),r.particulars,r.words,r.currency,fmt(r.amount),r.rate,fmt(r.usd)].map(x=>'<td>'+esc(x)+'</td>').join('')+'</tr>').join('')+'</tbody></table><h3>Total expenses submitted: US$ '+fmt(total)+'</h3><p>Submitted to management for approval of petty cash replenishment. Requested amount: US$ '+fmt(total)+'. Final cheque amount / reference: ____________________</p><div class="sign"><div>Prepared by<br><br>Name / signature / date</div><div>Checked and verified by<br><br>Name / signature / date</div><div>Approved by<br><br>Name / signature / date</div></div><p>Petty cash summary for PrimeWay and Lollybird — expense report and supporting vouchers.</p></body></html>';
}
function csv(s){
 const cols=['Date','PCV No','Paid to','Agent','Depot','Particulars','Amount in words','Currency','Original amount','LD per USD','USD expense','Cycle','Photo'];
 const cell=v=>{let x=String(v??'');if(/^[=+\-@]/.test(x))x="'"+x;return '"'+x.replaceAll('"','""')+'"';};
 return '\ufeff'+[cols,...s.vouchers.map(r=>[r.date,r.number,r.paid_to,r.agent,r.depot,r.particulars,r.words,r.currency,(r.amount/100).toFixed(2),r.rate,(r.usd/100).toFixed(2),r.cycle,r.photo])].map(row=>row.map(cell).join(',')).join('\r\n');
}
const api={empty,money,validDate,balance,cycle,nameKey,initializeMaster,resolveAgent,addDepot,saveAgent,status,fund,setRate,rateFor,add,edit,extract,report,csv,esc,fmt};
global.Ledger=api;
})(typeof window!=='undefined'?window:globalThis);

(function(g){
const units=Object.fromEntries('zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen'.split(' ').map((x,i)=>[x,i]));
const tens=Object.fromEntries('twenty thirty forty fifty sixty seventy eighty ninety'.split(' ').map((x,i)=>[x,20+i*10]));
const months=Object.fromEntries('january february march april may june july august september october november december'.split(' ').map((x,i)=>[x,i+1]));
const ordinal={first:'one',second:'two',third:'three',fourth:'four',fifth:'five',sixth:'six',seventh:'seven',eighth:'eight',ninth:'nine',tenth:'ten',eleventh:'eleven',twelfth:'twelve',thirteenth:'thirteen',fourteenth:'fourteen',fifteenth:'fifteen',sixteenth:'sixteen',seventeenth:'seventeen',eighteenth:'eighteen',nineteenth:'nineteen',twentieth:'twenty',thirtieth:'thirty'};
function number(text,digits=false){
 text=text.toLowerCase().replace(/\b(?:liberian dollars?|us dollars?|united states dollars?|dollars?|usd|ld)\b/g,'').trim();if(/^\d[\d,]*(\.\d+)?$/.test(text))return text.replaceAll(',','');
 const tokens=(text.match(/[a-z]+|\d+/g)||[]).filter(x=>!['and','the','of'].includes(x)).map(x=>ordinal[x]||x);
 if(!tokens.length)throw Error('No number recognized.');
 if(digits&&tokens.every(x=>(units[x]!==undefined&&units[x]<10)||/^\d$/.test(x)))return tokens.map(x=>/^\d$/.test(x)?x:String(units[x])).join('');
 const point=tokens.indexOf('point');if(point>=0)return number(tokens.slice(0,point).join(' '))+'.'+number(tokens.slice(point+1).join(' '),true);
 let total=0,current=0;for(const t of tokens){if(/^\d+$/.test(t))current+=Number(t);else if(units[t]!==undefined)current+=units[t];else if(tens[t])current+=tens[t];else if(t==='hundred')current=Math.max(1,current)*100;else if(['thousand','million'].includes(t)){total+=Math.max(1,current)*(t==='thousand'?1000:1000000);current=0;}else throw Error('Number unclear; correct the recognized text.');}return String(total+current);
}
function voice(field,text,L){
 text=text.trim().replace(/\.$/,'');if(field==='number')return number(text,true);if(field==='amount'){if(/\d.*\b(?:LD|USD|dollars?)\b.*\d/i.test(text))throw Error('Split amount is ambiguous. Enter the full amount manually.');return number(text);}
 if(field==='currency'){if(/\bliberian\b|\bld\b|\bl\s+d\b/i.test(text))return 'LD';if(/\bunited states\b|\busd\b|\bu\s+s\b|\bus dollars?/i.test(text))return 'USD';throw Error('Say Liberian dollars or United States dollars.');}
 if(field==='date'){try{return L.validDate(text);}catch{}for(const [name,m] of Object.entries(months)){const match=text.match(new RegExp('\\b'+name+'\\b','i'));if(match)return L.validDate(number(text.slice(0,match.index).replace(/[,]/g,'').trim())+'-'+m+'-'+number(text.slice(match.index+name.length).replace(/[,]/g,'').trim()));}throw Error('Say: seven October two thousand twenty six.');}return text;
}
const boxes={number:[.775,.245,.925,.345],date:[.09,.265,.30,.365],paid_to:[.12,.38,.95,.455],words:[.16,.465,.96,.55],particulars:[.155,.555,.96,.64],amount:[.035,.745,.27,.845]};
function cloud(result,L){
 const text=result.content||'',v=L.extract(text),regions={},notes=[];const page=result.pages?.[0];
 if(page){for(const [key,b] of Object.entries(boxes)){const found=(page.words||[]).map(word=>{const p=word.polygon||[];if(p.length<8)return null;const x=(p[0]+p[2]+p[4]+p[6])/4/page.width,y=(p[1]+p[3]+p[5]+p[7])/4/page.height;return x>=b[0]&&x<=b[2]&&y>=b[1]&&y<=b[3]?{x,y,word}:null;}).filter(Boolean).sort((a,b)=>Math.round(a.y/.025)-Math.round(b.y/.025)||a.x-b.x);regions[key]=found.map(x=>x.word.content).join(' ');if(found.some(x=>(x.word.confidence??1)<.8))notes.push('Review low-confidence '+key);}}
 if(regions.number){const nums=regions.number.match(/\b\d{3,10}\b/g)||[];if(new Set(nums).size===1)v.number=nums[0];}
 if(regions.date){const candidates=regions.date.match(/\d{4}\s*[-/.]\s*\d{1,2}\s*[-/.]\s*\d{1,2}|\d{1,2}\s*[-/.,]\s*\d{1,2}\s*[-/.,]\s*\d{4}/g)||[];const dates=new Set();for(const t of candidates)try{dates.add(L.validDate(t.replace(/\s/g,'')));}catch{}if(dates.size===1)v.date=[...dates][0];else if(dates.size>1){delete v.date;notes.push('Overwritten date — confirm manually');}}
 for(const k of ['paid_to','words','particulars'])if(regions[k])v[k]=regions[k];
 if(regions.amount){const nums=regions.amount.match(/\d[\d,]*(?:\.\d{1,2})?/g)||[];if(new Set(nums).size>1){delete v.amount;notes.push('More than one amount — confirm manually');}else Object.assign(v,L.extract('Amount in Figure: '+regions.amount));}
 const amountSource=regions.amount||((text.match(/amount\s+in\s+figures?\s*[:_ -]*([^\n]+)/i)||[])[1]||'');
 const count=(amountSource.match(/\d[\d,]*(?:\.\d+)?/g)||[]).length;
 if(count!==1 || notes.some(n=>n==='Review low-confidence amount')){delete v.amount;notes.push('Amount requires manual confirmation; do not join separated figures automatically');}
 if(/\bLD\b|L\s*\$/i.test(amountSource)&&/\bUSD\b|US\s*\$/i.test(amountSource)){delete v.currency;notes.push('Conflicting currencies — choose from the photo');}
 if(!v.currency&&!notes.some(n=>n.startsWith('Conflicting currencies')))v.currency=L.extract('The Sum of: '+(regions.words||'')).currency;
 let wordsAmount;try{wordsAmount=number(v.words||'');}catch{}
 if(v.amount&&wordsAmount&&L.money(v.amount)!==L.money(wordsAmount)){delete v.amount;notes.push('Amount in figures differs from amount in words — confirm from photo');}
 return {fields:v,text:text+'\n\nONLINE FIELD TEXT\n'+Object.entries(regions).map(([k,t])=>k+': '+t).join('\n')+'\n'+notes.join('\n'),notes};
}
const api={number,voice,cloud};g.InputHelpers=api;
})(typeof window!=='undefined'?window:globalThis);

const AGENTS = {
  "Amara Jabatteh": "Freeport",
  "Willet Cooper": "16th street",
  "Mellisa Doe": "Boystown",
  "Vanesa Galls": "ELWA",
  "Andrew W Tarpe": "Gardnersville",
  "Cinequne B. Friday": "Jacobtown",
  "Peter Johnson": "Logan town",
  "Blessing": "Marshall-09",
  "De vil Joe": "Johnsonville",
  "Yuphemia Karzon": "Gbngbarstown",
  "Rachel Gray": "Caldwell",
  "Franciz K Zuo": "Kpanstown",
  "Betty Korpha": "Kebah",
  "Benadict": "Wheins Town",
  "Elizabath Sumo": "New JJ eagle",
  "Jackie Dennies": "Duazon rock crusher",
  "Jacoblyne": "Sandbeach",
  "Robert F Okai": "Unification city",
  "Mossus N. Yallah": "Winners chappel",
  "James Matadi": "MountBarklay",
  "Ellen Chea": "Palmwine station",
  "Alvin Gonegrant": "Newtown Johnsonville",
  "Richard": "Soul Clinic",
  "Alex Tokpha": "Pipeline Road",
  "Rose": "Folytown",
  "Memah": "Barnersville LPRC"
};

/* Google Apps Script V8. Append the supplied Ledger.gs in the same project. */
function setupPrimeWay() {
 const p=PropertiesService.getScriptProperties();if(p.getProperty('DATABASE_ID'))throw Error('Already initialized.');
 const folder=DriveApp.createFolder('PrimeWay Lollybird Shared Petty Cash');
 const token=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');
 const db={revision:0,state:Ledger.empty(),users:[{id:Utilities.getUuid(),name:'Administrator',role:'admin',active:true,tokenHash:hashToken(token)}],audit:[]};
 Ledger.initializeMaster(db.state,AGENTS);
 const file=folder.createFile('database.json',JSON.stringify(db),'application/json');
 p.setProperties({DATABASE_ID:file.getId(),FOLDER_ID:folder.getId()});
 console.log('PRIVATE ADMIN ACCESS CODE (keep secret): '+token);console.log('Drive folder: '+folder.getUrl());
}
function hashToken(t){return Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(t)).map(b=>('0'+((b+256)%256).toString(16)).slice(-2)).join('');}
function same(a,b){return stable(a)===stable(b);}
function stable(v){if(Array.isArray(v))return '['+v.map(stable).join(',')+']';if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+stable(v[k])).join(',')+'}';return JSON.stringify(v);}
function publicUser(u){return {id:u.id,name:u.name,role:u.role,active:u.active};}
function transition(old,next,user){
 const s=JSON.parse(JSON.stringify(old));
 const allowed=['version','threshold','funds','vouchers','rates','masterVersion','agents','depots'];
 if(Object.keys(next).some(k=>!allowed.includes(k))||next.version!==1||next.masterVersion!==1)throw Error('Invalid ledger schema.');
 const changed=allowed.filter(k=>!same(old[k],next[k]));if(changed.length!==1&&!(changed.length===2&&changed.includes('agents')&&changed.includes('depots')))throw Error('Save one change at a time.');
 let action='';
 if(changed.includes('vouchers')){
  if(!['admin','editor','entry'].includes(user.role))throw Error('Your role cannot enter vouchers.');
  if(next.vouchers.length===old.vouchers.length+1&&same(next.vouchers.slice(0,-1),old.vouchers)){
   const v=next.vouchers[next.vouchers.length-1];validateVoucher(v);if(!v.reviewed)throw Error('Review all voucher fields before saving.');
   Ledger.add(s,{...v,amount:(v.amount/100).toFixed(2)});action='voucher.add';
  }else if(next.vouchers.length===old.vouchers.length&&['admin','editor'].includes(user.role)){
   const diffs=next.vouchers.map((v,i)=>same(v,old.vouchers[i])?-1:i).filter(i=>i>=0);if(diffs.length!==1)throw Error('Edit one voucher at a time.');
   const i=diffs[0],v=next.vouchers[i],previous=old.vouchers[i];validateVoucher(v);for(const k of ['photo','hash','voiceNote','cloudPhoto','cloudNote','createdBy','createdAt','updatedBy','updatedAt'])if(!same(v[k],previous[k]))throw Error('Source attachments and audit metadata cannot be changed.');if(!v.reviewed||v.id!==previous.id)throw Error('Invalid voucher edit.');
   Ledger.edit(s,v.id,{...v,amount:(v.amount/100).toFixed(2)});action='voucher.edit';
  }else throw Error('Your role cannot edit or remove saved vouchers.');
 }else{
  if(user.role!=='admin')throw Error('Only Admin can change cash, rates, agents, depots or settings.');
  if(changed[0]==='funds'&&next.funds.length===old.funds.length+1&&same(next.funds.slice(0,-1),old.funds)){
   const f=next.funds[next.funds.length-1];Ledger.fund(s,{...f,amount:(f.amount/100).toFixed(2)});action='cash.receive';
  }else if(changed[0]==='threshold'){s.threshold=Ledger.money((next.threshold/100).toFixed(2));action='threshold.change';
  }else if(changed[0]==='rates'){
   const differences=next.rates.filter(r=>!old.rates.some(x=>same(x,r)));if(differences.length!==1)throw Error('Change one rate at a time.');Ledger.setRate(s,differences[0].date,differences[0].rate);action='rate.change';
  }else if(changed[0]==='depots'&&next.depots.length===old.depots.length+1){const d=next.depots.find(x=>!old.depots.includes(x));Ledger.addDepot(s,d);action='depot.add';
  }else if(changed.includes('agents')){
   const diffs=next.agents.filter(a=>!old.agents.some(x=>same(x,a)));if(diffs.length!==1)throw Error('Change one agent at a time.');
   const removed=old.agents.filter(a=>!next.agents.some(x=>same(x,a)));if(removed.length>1)throw Error('Invalid agent change.');
   const a=diffs[0];Ledger.saveAgent(s,{...a,old_name:removed[0]?.name||''});action='agent.change';
  }else throw Error('Unsupported change.');
 }
 if(!same(s,next))throw Error('Validation failed: unexpected or inconsistent fields. Refresh and review.');
 return {state:s,action};
}
function validateVoucher(v){
 const keys=['number','date','paid_to','agent','depot','particulars','words','currency','amount','rate','photo','hash','voiceNote','reviewed','id','usd','cycle','cloudPhoto','cloudNote','createdBy','createdAt','updatedBy','updatedAt'];
 if(Object.keys(v).some(k=>!keys.includes(k)))throw Error('Unknown voucher field.');
 for(const k of ['number','paid_to','particulars','words'])if(typeof v[k]!=='string'||v[k].length>2000)throw Error('Invalid voucher text.');
 let words;try{words=InputHelpers.number(v.words.replace(/\bonly\b/gi,''));}catch{}
 if(words!==undefined&&Ledger.money(words)!==v.amount)throw Error('Amount in figures and words differ. Correct the voucher before saving.');
}
function doPost(e){
 const lock=LockService.getScriptLock();let locked=false;
 try{
  if(!e?.postData?.contents||e.postData.contents.length>16000000)throw Error('Request missing or too large.');
  const q=JSON.parse(e.postData.contents);if(!/^[a-f0-9]{64}$/i.test(q.token||''))throw Error('Access denied.');
  lock.waitLock(25000);locked=true;
  const p=PropertiesService.getScriptProperties(),file=DriveApp.getFileById(p.getProperty('DATABASE_ID')),db=JSON.parse(file.getBlob().getDataAsString());
  const u=db.users.find(x=>x.active&&x.tokenHash===hashToken(q.token));if(!u)throw Error('Access denied: wrong or revoked access code.');
  const response=()=>({ok:true,revision:db.revision,state:db.state,user:publicUser(u),users:u.role==='admin'?db.users.map(publicUser):[],reader:readerSettings(),audit:u.role==='admin'?db.audit.slice(-100):[]});
  if(q.action==='load')return output(response());
  if(q.action==='ocr.start'||q.action==='ocr.poll'){lock.releaseLock();locked=false;return output(azureRead(q,u));}
  if(q.action==='reader.settings'){
   if(u.role!=='admin')throw Error('Admin required.');
   const endpoint=azureEndpoint(q.endpoint);const key=String(q.key||'').trim();
   if(key&&!/^[A-Za-z0-9_-]{16,256}$/.test(key))throw Error('Invalid Azure key.');
   if(q.enabled&&!key&&!p.getProperty('AZURE_KEY'))throw Error('Enter the Azure key.');
   p.setProperty('AZURE_ENDPOINT',endpoint);if(key)p.setProperty('AZURE_KEY',key);p.setProperty('AZURE_ENABLED',q.enabled?'true':'false');
   return output(response());
  }
  if(q.action==='attachment'){
   const refs=db.state.vouchers.flatMap(v=>[v.cloudPhoto,v.cloudNote]).filter(Boolean);if(!refs.includes(q.fileId))throw Error('Attachment not in this database.');
   const blob=DriveApp.getFileById(q.fileId).getBlob();return output({ok:true,data:Utilities.base64Encode(blob.getBytes())});
  }
  if(q.action==='sync.voucher'){
   if(!/^[A-Za-z0-9_-]{10,100}$/.test(q.operationId||''))throw Error('Invalid sync operation.');
   db.syncReceipts=db.syncReceipts||{};
   const receipt=db.syncReceipts[q.operationId];
   if(receipt){if(receipt.user!==u.id||receipt.payload!==stable({kind:q.kind,voucher:q.voucher,base:q.base}))throw Error('Sync operation identity mismatch.');return output({...response(),operationId:q.operationId});}
   const candidate=JSON.parse(JSON.stringify(db.state));
   if(q.kind==='add'){if(q.voucher.cycle!==Ledger.cycle(db.state))throw Error('Conflict: cash was replenished since entry. Pending voucher retained; ask Admin to review its cash cycle.');Ledger.add(candidate,q.voucher);}
   else if(q.kind==='edit'){
    const current=db.state.vouchers.find(v=>v.id===q.base?.id);
    if(!current||!same(current,q.base))throw Error('Conflict: this voucher changed on another device. Pending correction retained; review before retrying.');
    Ledger.edit(candidate,current.id,q.voucher);
   }else throw Error('Invalid sync kind.');
   q.state=candidate;q.action='save';q.revision=db.revision;
  }
  if(q.revision!==db.revision)return output({ok:false,conflict:true,error:'Another user saved a change. Your form is kept. Refresh shared data and retry.'});
  let action,issuedToken;
  if(q.action==='save'){
   const t=transition(db.state,q.state,u);action=t.action;
   // Existing media references cannot be changed by an edit. New attachments are validated and private.
   if(action==='voucher.add'){
    const v=t.state.vouchers[t.state.vouchers.length-1];if(v.cloudPhoto||v.cloudNote||v.createdBy)throw Error('Invalid new attachment metadata.');
    const folder=DriveApp.getFolderById(p.getProperty('FOLDER_ID'));
    for(const [key,field,mime] of [['photo','cloudPhoto','image/jpeg'],['note','cloudNote','audio/mp4']]){
     const data=q.attachments?.[key];if(v[key==='photo'?'photo':'voiceNote']&&!data)throw Error('Attachment missing. Please retry.');
     if(data){if(typeof data!=='string'||data.length>11000000||!/^[A-Za-z0-9+/=]+$/.test(data))throw Error('Attachment too large or invalid.');
      const blob=Utilities.newBlob(Utilities.base64Decode(data),mime,'PCV_'+v.number.replace(/[^A-Za-z0-9_-]/g,'_')+'_'+Utilities.getUuid()+(key==='photo'?'.jpg':'.m4a'));
      v[field]=folder.createFile(blob).getId();
     }
    }
    v.createdBy=u.name;v.createdAt=new Date().toISOString();
   }
   if(action==='voucher.edit'){const v=t.state.vouchers.find((v,i)=>!same(v,db.state.vouchers[i]));v.updatedBy=u.name;v.updatedAt=new Date().toISOString();}
   db.state=t.state;
   if(q.operationId){db.syncReceipts[q.operationId]={user:u.id,payload:stable({kind:q.kind,voucher:q.voucher,base:q.base})};}
  }else if(q.action==='user.add'){
   if(u.role!=='admin')throw Error('Admin required.');const name=String(q.name||'').trim();if(!name||name.length>100||!['admin','editor','entry','viewer'].includes(q.role))throw Error('Enter name and valid role.');
   if(db.users.some(x=>x.active&&x.name.toLowerCase()===name.toLowerCase()))throw Error('User name already exists.');
   issuedToken=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');db.users.push({id:Utilities.getUuid(),name,role:q.role,active:true,tokenHash:hashToken(issuedToken)});action='user.add';
  }else if(q.action==='user.update'){
   if(u.role!=='admin')throw Error('Admin required.');const target=db.users.find(x=>x.id===q.userId);if(!target||!['admin','editor','entry','viewer'].includes(q.role)||typeof q.active!=='boolean')throw Error('Invalid user change.');
   if(target.id===u.id)throw Error('Ask another admin to change your own account.');
   if(target.role==='admin'&&target.active&&(q.role!=='admin'||!q.active)&&db.users.filter(x=>x.active&&x.role==='admin').length<=1)throw Error('Keep at least one active admin.');
   target.role=q.role;target.active=q.active;action='user.update';
  }else throw Error('Unknown operation.');
  const prior=file.getBlob();DriveApp.getFolderById(p.getProperty('FOLDER_ID')).createFile(Utilities.newBlob(prior.getBytes(),'application/json','revision_'+db.revision+'.json'));
  db.revision++;db.audit.push({revision:db.revision,at:new Date().toISOString(),by:u.name,action});if(db.audit.length>2000)db.audit=db.audit.slice(-2000);
  file.setContent(JSON.stringify(db));return output({...response(),issuedToken,operationId:q.operationId});
 }catch(err){return output({ok:false,error:String(err.message||err)});}finally{if(locked)lock.releaseLock();}
}
function output(value){return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);}

function azureEndpoint(value){const s=String(value||'').trim().replace(/\/$/,'');if(!/^https:\/\/[A-Za-z0-9-]+\.(cognitiveservices\.azure\.com|services\.ai\.azure\.com)$/.test(s))throw Error('Use the Azure resource HTTPS endpoint.');return s;}
function readerSettings(){const p=PropertiesService.getScriptProperties();return {endpoint:p.getProperty('AZURE_ENDPOINT')||'https://primeway.cognitiveservices.azure.com',enabled:p.getProperty('AZURE_ENABLED')!=='false'&&!!p.getProperty('AZURE_KEY'),configured:!!p.getProperty('AZURE_KEY')};}
function azureRead(q,u){
 if(!['admin','editor','entry'].includes(u.role))throw Error('Your role cannot read new vouchers.');
 const p=PropertiesService.getScriptProperties(),settings=readerSettings(),endpoint=azureEndpoint(settings.endpoint),key=p.getProperty('AZURE_KEY');if(!settings.enabled)throw Error('Azure reader is not configured. Ask your administrator to edit reader settings.');
 const cache=CacheService.getScriptCache();let job,operation;
 if(q.action==='ocr.start'){
  if(typeof q.image!=='string'||q.image.length>5400000||!/^[A-Za-z0-9+/=]+$/.test(q.image))throw Error('Photo invalid or too large (maximum 4 MB).');
  const bytes=Utilities.base64Decode(q.image);if(bytes.length>4000000||bytes.length<3||((bytes[0]+256)%256)!==255||((bytes[1]+256)%256)!==216)throw Error('Upload a JPEG photo under 4 MB.');
  const r=UrlFetchApp.fetch(endpoint+'/documentintelligence/documentModels/prebuilt-read:analyze?api-version=2024-11-30',{method:'post',contentType:'application/octet-stream',payload:bytes,headers:{'Ocp-Apim-Subscription-Key':key},muteHttpExceptions:true,followRedirects:false});
  if(r.getResponseCode()!==202)throw Error('Azure returned HTTP '+r.getResponseCode()+'. Check settings or request limits.');
  const headers=r.getAllHeaders();operation=headers['Operation-Location']||headers['operation-location'];
  if(typeof operation!=='string'||!operation.startsWith(endpoint+'/documentintelligence/'))throw Error('Unexpected Azure result address.');
  job=Utilities.getUuid();cache.put('ocr:'+job,JSON.stringify({user:u.id,operation}),300);return {ok:true,job};
 }
 job=String(q.job||'');if(!/^[A-Za-z0-9-]{1,100}$/.test(job))throw Error('Invalid reading job.');const saved=cache.get('ocr:'+job);if(!saved)throw Error('Reading job expired. Take or select the photo again.');const entry=JSON.parse(saved);if(entry.user!==u.id)throw Error('Reading job belongs to another user.');operation=entry.operation;
 if(!operation.startsWith(endpoint+'/documentintelligence/'))throw Error('Reader settings changed. Restart reading.');
 const r=UrlFetchApp.fetch(operation,{headers:{'Ocp-Apim-Subscription-Key':key},muteHttpExceptions:true,followRedirects:false});if(r.getResponseCode()!==200)throw Error('Azure returned HTTP '+r.getResponseCode()+'.');const result=JSON.parse(r.getContentText());
 if(result.status==='succeeded'){cache.remove('ocr:'+job);return {ok:true,analysis:result.analyzeResult};}if(['failed','canceled'].includes(result.status)){cache.remove('ocr:'+job);throw Error('Azure could not read this photo.');}return {ok:true,pending:true};
}

function authorizeExternalAccess() {
 UrlFetchApp.fetch('https://www.google.com',{muteHttpExceptions:true});
 console.log('External request permission is ready.');
}
